import React, { useState } from 'react';
import { LogIn, UserPlus, X, AlertCircle, ShieldCheck } from 'lucide-react';
import { loginTeacher, registerTeacher } from '../lib/storage';
import { TeacherUser } from '../types';
import { INITIAL_TEACHERS } from '../lib/sampleData';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onTeacherAuthenticated: (teacher: TeacherUser) => void;
  isSupabaseMode: boolean;
}

export const AuthModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onTeacherAuthenticated,
  isSupabaseMode,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [assignedClass, setAssignedClass] = useState('Grade 10');
  const [assignedSection, setAssignedSection] = useState('A');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (mode === 'login') {
        const res = await loginTeacher(email, password);
        if (res.success && res.teacher) {
          onTeacherAuthenticated(res.teacher);
          onClose();
        } else {
          setError(res.error || 'Failed to sign in. Verify email and password.');
        }
      } else {
        if (!name.trim()) {
          setError('Please enter your full name.');
          setLoading(false);
          return;
        }
        const res = await registerTeacher(email, password, name.trim(), assignedClass, assignedSection);
        if (res.success && res.teacher) {
          onTeacherAuthenticated(res.teacher);
          onClose();
        } else {
          setError(res.error || 'Failed to create teacher account.');
        }
      }
    } catch (err: any) {
      setError(err?.message || 'Authentication error occurred.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickLogin = async (teacher: TeacherUser) => {
    setError(null);
    setLoading(true);
    const res = await loginTeacher(teacher.email, 'teacher123');
    setLoading(false);
    if (res.success && res.teacher) {
      onTeacherAuthenticated(res.teacher);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="relative w-full max-w-md bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-indigo-600" />
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                {mode === 'login' ? 'Teacher Portal Sign In' : 'Teacher Staff Registration'}
              </h2>
              <p className="text-[11px] text-slate-500">
                {isSupabaseMode ? 'Authenticating via Supabase Cloud' : 'Local School Database Mode'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Demo Switcher */}
        <div className="px-6 py-3 bg-indigo-50/70 border-b border-indigo-100/60">
          <p className="text-[11px] font-semibold text-indigo-900 mb-1.5">Quick Demo Teacher Profiles:</p>
          <div className="flex flex-wrap gap-1.5">
            {INITIAL_TEACHERS.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => handleQuickLogin(t)}
                className="px-2 py-1 text-[11px] font-medium bg-white text-indigo-950 border border-indigo-200 hover:bg-indigo-100 rounded transition-colors"
              >
                {t.name} ({t.assigned_class}-{t.assigned_section})
              </button>
            ))}
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {mode === 'register' && (
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Full Teacher Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dr. Robert Vance"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Assigned Class</label>
                  <select
                    value={assignedClass}
                    onChange={(e) => {
                      const nextClass = e.target.value;
                      setAssignedClass(nextClass);
                      if (nextClass === 'Class 11' || nextClass === 'Class 12') {
                        setAssignedSection('Science');
                      } else {
                        setAssignedSection('A');
                      }
                    }}
                    className="w-full px-2.5 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    {[
                      'Class 1',
                      'Class 2',
                      'Class 3',
                      'Class 4',
                      'Class 5',
                      'Class 6',
                      'Class 7',
                      'Class 8',
                      'Class 9',
                      'Class 10',
                      'Class 11',
                      'Class 12',
                    ].map((cls) => (
                      <option key={cls} value={cls}>
                        {cls}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {assignedClass === 'Class 11' || assignedClass === 'Class 12' ? 'Stream' : 'Section'}
                  </label>
                  <select
                    value={assignedSection}
                    onChange={(e) => setAssignedSection(e.target.value)}
                    className="w-full px-2.5 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium"
                  >
                    {assignedClass === 'Class 11' || assignedClass === 'Class 12' ? (
                      <>
                        <option value="Science">Science</option>
                        <option value="Commerce">Commerce</option>
                        <option value="Humanities">Humanities</option>
                      </>
                    ) : (
                      <>
                        <option value="A">Section A</option>
                        <option value="B">Section B</option>
                      </>
                    )}
                  </select>
                </div>
              </div>
            </>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">School Email Address</label>
            <input
              type="email"
              required
              placeholder="teacher@westlake.edu"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Password</label>
            <input
              type="password"
              required
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors flex items-center justify-center gap-1.5 disabled:opacity-50 mt-2"
          >
            {loading ? (
              <span>Authenticating...</span>
            ) : mode === 'login' ? (
              <>
                <LogIn className="w-4 h-4" /> Sign In as Teacher
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4" /> Create Teacher Account
              </>
            )}
          </button>

          <div className="text-center pt-2">
            <button
              type="button"
              onClick={() => {
                setMode(mode === 'login' ? 'register' : 'login');
                setError(null);
              }}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-medium"
            >
              {mode === 'login'
                ? 'Need to register a new teacher? Click here'
                : 'Already have an account? Sign in'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
