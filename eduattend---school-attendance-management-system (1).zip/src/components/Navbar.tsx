import React from 'react';
import { User } from 'lucide-react';
import { TeacherUser } from '../types';

interface Props {
  activeTab: 'daily' | 'monthly' | 'students' | 'analytics';
  setActiveTab: (tab: 'daily' | 'monthly' | 'students' | 'analytics') => void;
  currentTeacher: TeacherUser | null;
  onOpenAuth: () => void;
  onOpenProfile: () => void;
  onOpenDatabaseSetup: () => void;
  isSupabaseConnected: boolean;
}

export const Navbar: React.FC<Props> = ({
  activeTab,
  setActiveTab,
  currentTeacher,
  onOpenAuth,
  onOpenProfile,
  onOpenDatabaseSetup,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
      <div className="w-full px-2 sm:px-4 md:px-6">
        <div className="flex items-center justify-between gap-4 sm:gap-8 h-16">
          {/* Zone 1: Brand Wordmark (Single text element, no subtitle badges) */}
          <button
            onClick={() => setActiveTab('daily')}
            className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 hover:text-indigo-600 transition-colors text-left"
          >
            PM Shri KV Masimpur
          </button>

          {/* Zone 2: 4-5 concise single-line nav links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
            <button
              onClick={() => setActiveTab('daily')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'daily' ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600 pb-0.5' : ''
              }`}
            >
              Daily Attendance
            </button>
            <button
              onClick={() => setActiveTab('monthly')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'monthly' ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600 pb-0.5' : ''
              }`}
            >
              Monthly Register
            </button>
            <button
              onClick={() => setActiveTab('students')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'students' ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600 pb-0.5' : ''
              }`}
            >
              Student Directory
            </button>
            <button
              onClick={() => setActiveTab('analytics')}
              className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'analytics' ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600 pb-0.5' : ''
              }`}
            >
              Analytics
            </button>
            <button
              onClick={onOpenDatabaseSetup}
              className="text-slate-500 hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
            >
              Database Setup
            </button>
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenProfile}
              className="px-3 py-1.5 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0 border border-slate-200 flex items-center gap-1.5 cursor-pointer"
              title="Click to view or edit teacher profile"
            >
              <User className="w-3.5 h-3.5 text-slate-500" />
              <span className="hidden sm:inline">Teacher: </span>
              <strong className="text-slate-900">{currentTeacher?.name || 'Omorjit Singha'}</strong>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav Bar (Visible on screens smaller than md) */}
      <div className="md:hidden flex overflow-x-auto px-4 py-2.5 border-t border-slate-200 bg-slate-50 gap-5 text-xs font-semibold scrollbar-none shrink-0">
        <button
          onClick={() => setActiveTab('daily')}
          className={`whitespace-nowrap pb-0.5 transition-colors ${
            activeTab === 'daily' ? 'text-indigo-600 font-bold border-b-2 border-indigo-600' : 'text-slate-600'
          }`}
        >
          Daily Attendance
        </button>
        <button
          onClick={() => setActiveTab('monthly')}
          className={`whitespace-nowrap pb-0.5 transition-colors ${
            activeTab === 'monthly' ? 'text-indigo-600 font-bold border-b-2 border-indigo-600' : 'text-slate-600'
          }`}
        >
          Monthly Register
        </button>
        <button
          onClick={() => setActiveTab('students')}
          className={`whitespace-nowrap pb-0.5 transition-colors ${
            activeTab === 'students' ? 'text-indigo-600 font-bold border-b-2 border-indigo-600' : 'text-slate-600'
          }`}
        >
          Student Directory
        </button>
        <button
          onClick={() => setActiveTab('analytics')}
          className={`whitespace-nowrap pb-0.5 transition-colors ${
            activeTab === 'analytics' ? 'text-indigo-600 font-bold border-b-2 border-indigo-600' : 'text-slate-600'
          }`}
        >
          Analytics
        </button>
        <button
          onClick={onOpenDatabaseSetup}
          className="whitespace-nowrap pb-0.5 text-slate-600 hover:text-indigo-600 transition-colors"
        >
          Database Setup
        </button>
      </div>
    </header>
  );
};
