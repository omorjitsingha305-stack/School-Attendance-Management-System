import React, { useMemo } from 'react';
import { Users, Award, AlertTriangle, Phone, BarChart2 } from 'lucide-react';
import { Student, AttendanceRecord } from '../types';

interface Props {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
  onNavigateToRollCall: () => void;
}

export const AnalyticsView: React.FC<Props> = ({
  students,
  attendanceRecords,
  onNavigateToRollCall,
}) => {
  // Class groups
  const classBreakdowns = useMemo(() => {
    const classMap: Record<
      string,
      { totalStudents: number; presentRecords: number; totalRecords: number }
    > = {};

    // Group students by Class
    students.forEach((s) => {
      const classKey = `${s.grade} - ${s.section}`;
      if (!classMap[classKey]) {
        classMap[classKey] = { totalStudents: 0, presentRecords: 0, totalRecords: 0 };
      }
      classMap[classKey].totalStudents++;
    });

    // Map student to classKey
    const studentToClass = new Map<string, string>();
    students.forEach((s) => studentToClass.set(s.id, `${s.grade} - ${s.section}`));

    attendanceRecords.forEach((r) => {
      const classKey = studentToClass.get(r.student_id);
      if (classKey && classMap[classKey]) {
        classMap[classKey].totalRecords++;
        if (r.status === 'present' || r.status === 'late' || r.status === 'leave') {
          classMap[classKey].presentRecords++;
        }
      }
    });

    const list = Object.entries(classMap).map(([name, data]) => {
      const rate =
        data.totalRecords > 0 ? Math.round((data.presentRecords / data.totalRecords) * 100) : 100;
      return {
        className: name,
        studentCount: data.totalStudents,
        rate,
        totalRecords: data.totalRecords,
      };
    });

    return list.sort((a, b) => b.rate - a.rate);
  }, [students, attendanceRecords]);

  // Overall counts
  const overallStats = useMemo(() => {
    let presentCount = 0;
    let absentCount = 0;
    let lateCount = 0;
    let leaveCount = 0;

    attendanceRecords.forEach((r) => {
      if (r.status === 'present') presentCount++;
      else if (r.status === 'absent') absentCount++;
      else if (r.status === 'late') lateCount++;
      else if (r.status === 'leave') leaveCount++;
    });

    const totalMarked = attendanceRecords.length;
    const overallRate =
      totalMarked > 0
        ? Math.round(((presentCount + lateCount + leaveCount) / totalMarked) * 100)
        : 95;

    return {
      totalMarked,
      presentCount,
      absentCount,
      lateCount,
      leaveCount,
      overallRate,
    };
  }, [attendanceRecords]);

  // Identify at-risk students (< 75% attendance)
  const atRiskStudents = useMemo(() => {
    const studentStats: Record<
      string,
      { total: number; present: number; student: Student }
    > = {};

    students.forEach((s) => {
      studentStats[s.id] = { total: 0, present: 0, student: s };
    });

    attendanceRecords.forEach((r) => {
      if (studentStats[r.student_id]) {
        studentStats[r.student_id].total++;
        if (r.status === 'present' || r.status === 'late' || r.status === 'leave') {
          studentStats[r.student_id].present++;
        }
      }
    });

    const list = Object.values(studentStats)
      .map(({ student, total, present }) => {
        const rate = total > 0 ? Math.round((present / total) * 100) : 100;
        return { student, total, present, rate };
      })
      .filter((item) => item.total >= 3 && item.rate < 75);

    return list.sort((a, b) => a.rate - b.rate);
  }, [students, attendanceRecords]);

  const bestClass = classBreakdowns[0] || { className: 'Class 10 - A', rate: 96 };

  return (
    <div className="space-y-6">
      {/* Top Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Students */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500">Total Enrolled</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-slate-900 tabular-nums">{students.length}</div>
          <div className="text-[11px] text-slate-500 mt-1">Across {classBreakdowns.length} sections</div>
        </div>

        {/* Overall School Attendance */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500">School Attendance Rate</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <BarChart2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-emerald-700 tabular-nums">
            {overallStats.overallRate}%
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {overallStats.totalMarked} roll call entries recorded
          </div>
        </div>

        {/* Top Performing Class */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500">Highest Attendance</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-bold text-slate-900 truncate">{bestClass.className}</div>
          <div className="text-[11px] text-emerald-700 font-semibold mt-1 tabular-nums">
            {bestClass.rate}% average attendance
          </div>
        </div>

        {/* At-Risk Students */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-500">Students &lt;75% Attendance</span>
            <div className="w-8 h-8 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-rose-700 tabular-nums">{atRiskStudents.length}</div>
          <div className="text-[11px] text-slate-500 mt-1">Require parent attendance intervention</div>
        </div>
      </div>

      {/* Class Comparison & Status Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Class-by-Class Attendance Rates */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Attendance by Class & Section</h3>
              <p className="text-xs text-slate-500">Comparison of roll-call consistency</p>
            </div>
          </div>

          <div className="space-y-3.5 pt-2">
            {classBreakdowns.map((item) => (
              <div key={item.className} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-800">{item.className}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-500">{item.studentCount} students</span>
                    <span className="font-mono font-bold text-slate-900 tabular-nums w-10 text-right">
                      {item.rate}%
                    </span>
                  </div>
                </div>
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      item.rate >= 90
                        ? 'bg-emerald-500'
                        : item.rate >= 75
                        ? 'bg-indigo-500'
                        : 'bg-rose-500'
                    }`}
                    style={{ width: `${Math.min(100, item.rate)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Status Distribution Breakdown */}
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Recorded Status Breakdown</h3>
            <p className="text-xs text-slate-500">Distribution across all historical entries</p>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="p-3.5 rounded-lg bg-emerald-50/60 border border-emerald-200/60">
              <span className="text-[11px] font-semibold text-emerald-800 block">Total Present</span>
              <span className="text-2xl font-bold text-emerald-700 tabular-nums">
                {overallStats.presentCount}
              </span>
              <span className="text-[11px] text-emerald-600 block mt-0.5">
                {overallStats.totalMarked > 0
                  ? Math.round((overallStats.presentCount / overallStats.totalMarked) * 100)
                  : 0}
                % of records
              </span>
            </div>

            <div className="p-3.5 rounded-lg bg-rose-50/60 border border-rose-200/60">
              <span className="text-[11px] font-semibold text-rose-800 block">Total Absent</span>
              <span className="text-2xl font-bold text-rose-700 tabular-nums">
                {overallStats.absentCount}
              </span>
              <span className="text-[11px] text-rose-600 block mt-0.5">
                {overallStats.totalMarked > 0
                  ? Math.round((overallStats.absentCount / overallStats.totalMarked) * 100)
                  : 0}
                % of records
              </span>
            </div>

            <div className="p-3.5 rounded-lg bg-amber-50/60 border border-amber-200/60">
              <span className="text-[11px] font-semibold text-amber-800 block">Total Late</span>
              <span className="text-2xl font-bold text-amber-700 tabular-nums">
                {overallStats.lateCount}
              </span>
              <span className="text-[11px] text-amber-600 block mt-0.5">
                {overallStats.totalMarked > 0
                  ? Math.round((overallStats.lateCount / overallStats.totalMarked) * 100)
                  : 0}
                % of records
              </span>
            </div>

            <div className="p-3.5 rounded-lg bg-indigo-50/60 border border-indigo-200/60">
              <span className="text-[11px] font-semibold text-indigo-800 block">Total Leaves</span>
              <span className="text-2xl font-bold text-indigo-700 tabular-nums">
                {overallStats.leaveCount}
              </span>
              <span className="text-[11px] text-indigo-600 block mt-0.5">
                {overallStats.totalMarked > 0
                  ? Math.round((overallStats.leaveCount / overallStats.totalMarked) * 100)
                  : 0}
                % sanctioned
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* At-Risk Intervention Roster */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">Attendance Intervention Alert Roster</h3>
              <p className="text-xs text-slate-500">
                Students below the school-wide 75% attendance threshold
              </p>
            </div>
          </div>
        </div>

        {atRiskStudents.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500">
            Great news! No students currently fall below the 75% attendance threshold.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-600">
                  <th className="py-2.5 px-4 w-16">Roll</th>
                  <th className="py-2.5 px-4">Student Name</th>
                  <th className="py-2.5 px-4">Class</th>
                  <th className="py-2.5 px-4">Attendance Rate</th>
                  <th className="py-2.5 px-4">Parent / Guardian Contact</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {atRiskStudents.map(({ student, rate }) => (
                  <tr key={student.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900 tabular-nums">
                      #{student.roll_number}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-900">{student.name}</td>
                    <td className="py-3 px-4 text-slate-600">
                      {student.grade} - {student.section}
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-mono font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded tabular-nums">
                        {rate}%
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-800">{student.guardian_name}</div>
                      <a
                        href={`tel:${student.guardian_phone}`}
                        className="text-[11px] text-indigo-600 hover:text-indigo-800 font-mono flex items-center gap-1 mt-0.5"
                      >
                        <Phone className="w-3 h-3" /> {student.guardian_phone}
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
