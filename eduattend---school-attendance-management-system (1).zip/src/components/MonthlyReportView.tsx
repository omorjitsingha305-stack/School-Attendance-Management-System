import React, { useState, useMemo } from 'react';
import { Download, Printer, AlertTriangle } from 'lucide-react';
import { Student, AttendanceRecord, AttendanceStatus, MonthlyStudentSummary, TeacherUser } from '../types';
import { exportMonthlyAttendanceCsv } from '../lib/csvExport';
import { ALL_CLASSES, isSeniorClass, getAvailableSectionsOrStreams } from '../lib/schoolStructure';

interface Props {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
  currentTeacher?: TeacherUser | null;
}

const MONTH_NAMES = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

export const MonthlyReportView: React.FC<Props> = ({
  students,
  attendanceRecords,
  currentTeacher,
}) => {
  const currentDate = new Date();
  const [selectedYear, setSelectedYear] = useState<number>(currentDate.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<number>(currentDate.getMonth());
  const [selectedGrade, setSelectedGrade] = useState<string>('Class 10');
  const [selectedSection, setSelectedSection] = useState<string>('A');

  // Available classes & sections
  const availableGrades = useMemo(() => {
    const existing = students.map((s) => s.grade);
    return Array.from(new Set([...ALL_CLASSES, ...existing]));
  }, [students]);

  const isSenior = isSeniorClass(selectedGrade);

  const availableSections = useMemo(() => {
    if (selectedGrade === 'ALL') {
      const set = new Set(students.map((s) => s.section));
      return Array.from(set);
    }
    const defaultSections = getAvailableSectionsOrStreams(selectedGrade);
    const fromStudents = students.filter((s) => s.grade === selectedGrade).map((s) => s.section);
    return Array.from(new Set([...defaultSections, ...fromStudents]));
  }, [students, selectedGrade]);

  // Days in selected month
  const daysInMonth = useMemo(() => {
    return new Date(selectedYear, selectedMonth + 1, 0).getDate();
  }, [selectedYear, selectedMonth]);

  // Days array [1, 2, ..., daysInMonth]
  const daysArray = useMemo(() => {
    return Array.from({ length: daysInMonth }, (_, i) => i + 1);
  }, [daysInMonth]);

  // Filter students by selected Grade and Section
  const targetStudents = useMemo(() => {
    return students.filter((s) => {
      const matchGrade = selectedGrade === 'ALL' || s.grade === selectedGrade;
      const matchSec = selectedSection === 'ALL' || s.section === selectedSection;
      return matchGrade && matchSec;
    });
  }, [students, selectedGrade, selectedSection]);

  // Calculate monthly attendance summary per student
  const monthlySummaries: MonthlyStudentSummary[] = useMemo(() => {
    // Map records by `${student_id}-${date}`
    const recordLookup = new Map<string, AttendanceStatus>();
    attendanceRecords.forEach((r) => {
      recordLookup.set(`${r.student_id}-${r.date}`, r.status);
    });

    return targetStudents.map((student) => {
      const dailyStatus: Record<number, AttendanceStatus | null> = {};
      let totalPresent = 0;
      let totalAbsent = 0;
      let totalLate = 0;
      let totalLeave = 0;
      let workingDays = 0;

      daysArray.forEach((day) => {
        const dateObj = new Date(selectedYear, selectedMonth, day);
        const dayOfWeek = dateObj.getDay();
        const isSunday = dayOfWeek === 0;

        if (isSunday) {
          // Sunday is strictly a holiday: not present, not absent
          dailyStatus[day] = null;
          return;
        }

        const dateStr = `${selectedYear}-${String(selectedMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const status = recordLookup.get(`${student.id}-${dateStr}`) || null;

        dailyStatus[day] = status;

        // Saturday and regular weekdays with recorded attendance count as working days:
        if (status) {
          workingDays++;
          if (status === 'present') totalPresent++;
          else if (status === 'absent') totalAbsent++;
          else if (status === 'late') totalLate++;
          else if (status === 'leave') totalLeave++;
        }
      });

      // Attendance percentage: (Present + Leave + Late) / workingDays
      // (late students still attended class)
      const effectivePresent = totalPresent + totalLate + totalLeave;
      const attendancePercentage =
        workingDays > 0 ? Math.round((effectivePresent / workingDays) * 100) : 100;

      return {
        student,
        dailyStatus,
        totalPresent,
        totalAbsent,
        totalLate,
        totalLeave,
        workingDays,
        attendancePercentage,
      };
    });
  }, [targetStudents, attendanceRecords, selectedYear, selectedMonth, daysArray]);

  // Overall class monthly statistics
  const classStats = useMemo(() => {
    if (monthlySummaries.length === 0) return { avgRate: 0, lowCount: 0 };
    const totalPercentage = monthlySummaries.reduce((sum, s) => sum + s.attendancePercentage, 0);
    const avgRate = Math.round(totalPercentage / monthlySummaries.length);
    const lowCount = monthlySummaries.filter((s) => s.attendancePercentage < 75).length;
    return { avgRate, lowCount };
  }, [monthlySummaries]);

  // Export CSV
  const handleExportCsv = () => {
    exportMonthlyAttendanceCsv(
      monthlySummaries,
      selectedYear,
      MONTH_NAMES[selectedMonth],
      daysInMonth,
      selectedGrade,
      selectedSection
    );
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Filter and Controls Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Class (1 to 12)</label>
              <select
                value={selectedGrade}
                onChange={(e) => {
                  setSelectedGrade(e.target.value);
                  setSelectedSection('ALL');
                }}
                className="px-3 py-1.5 text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              >
                {availableGrades.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
                <option value="ALL">All Classes</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                {isSenior ? 'Stream (Science/Comm/Hum)' : 'Section'}
              </label>
              <select
                value={selectedSection}
                onChange={(e) => setSelectedSection(e.target.value)}
                className="px-3 py-1.5 text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium"
              >
                <option value="ALL">{isSenior ? 'All Streams' : 'All Sections'}</option>
                {availableSections.map((sec) => (
                  <option key={sec} value={sec}>
                    {isSenior ? `${sec} Stream` : `Section ${sec}`}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Month</label>
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(Number(e.target.value))}
                className="px-3 py-1.5 text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              >
                {MONTH_NAMES.map((name, index) => (
                  <option key={name} value={index}>
                    {name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Academic Year</label>
              <select
                value={selectedYear}
                onChange={(e) => setSelectedYear(Number(e.target.value))}
                className="px-3 py-1.5 text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-mono"
              >
                {[2024, 2025, 2026, 2027].map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
            </div>

            {/* Teacher Name */}
            <div>
              <span className="block text-[11px] font-semibold text-slate-500 mb-1">Teacher</span>
              <div className="px-3 py-1.5 text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg text-slate-800 flex items-center gap-1.5 h-[34px]">
                <span>{currentTeacher?.name || 'Omorjit Singha'}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end lg:self-auto">
            <button
              onClick={handlePrint}
              className="px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              Print Register
            </button>
            <button
              onClick={handleExportCsv}
              className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              Export Monthly CSV
            </button>
          </div>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-4 pt-3 border-t border-slate-100 text-[11px] text-slate-600">
          <span className="font-semibold text-slate-700">Attendance Key:</span>
          <div className="flex items-center gap-1.5">
            <span className="w-4 h-4 rounded bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-[10px]">P</span>
            <span>Present</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-4 h-4 rounded bg-rose-100 text-rose-800 font-bold flex items-center justify-center text-[10px]">A</span>
            <span>Absent</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-4 h-4 rounded bg-amber-100 text-amber-800 font-bold flex items-center justify-center text-[10px]">L</span>
            <span>Late</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-4 h-4 rounded bg-indigo-100 text-indigo-800 font-bold flex items-center justify-center text-[10px]">Lv</span>
            <span>Approved Leave</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-4 h-4 rounded bg-rose-100 text-rose-700 font-bold flex items-center justify-center text-[10px]">-</span>
            <span className="font-medium text-rose-700">Sunday Holiday (School Closed)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-4 h-4 rounded bg-amber-100 text-amber-900 font-bold flex items-center justify-center text-[10px]">Sa</span>
            <span className="font-semibold text-amber-900">Saturday (Working Day - Present)</span>
          </div>

          <div className="ml-auto flex items-center gap-3">
            <span className="font-medium text-slate-700 hidden sm:inline">
              Teacher: <strong className="text-slate-900">{currentTeacher?.name || 'Omorjit Singha'}</strong>
            </span>
            <span className="text-slate-300 hidden sm:inline" aria-hidden="true">|</span>
            <span className="font-medium text-slate-700">
              Class Average: <strong className="text-indigo-600 tabular-nums">{classStats.avgRate}%</strong>
            </span>
            {classStats.lowCount > 0 && (
              <span className="flex items-center gap-1 text-rose-600 font-medium">
                <AlertTriangle className="w-3.5 h-3.5" />
                {classStats.lowCount} student(s) below 75% threshold
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Monthly Attendance Matrix Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto max-h-[650px]">
          <table className="w-full min-w-[900px] text-left border-collapse text-xs">
            <thead className="sticky top-0 bg-slate-100 z-10 border-b border-slate-200">
              <tr className="text-[11px] font-bold text-slate-700">
                <th className="py-2.5 px-3 sticky left-0 bg-slate-100 z-20 border-r border-slate-200 shadow-xs w-14">Roll</th>
                <th className="py-2.5 px-3 sticky left-14 bg-slate-100 z-20 border-r border-slate-200 shadow-xs min-w-44">Student Name</th>
                {daysArray.map((day) => {
                  const dateObj = new Date(selectedYear, selectedMonth, day);
                  const dayOfWeek = dateObj.getDay();
                  const isSunday = dayOfWeek === 0;
                  const isSaturday = dayOfWeek === 6;
                  return (
                    <th
                      key={day}
                      title={
                        isSunday
                          ? `Day ${day} - Sunday (Holiday)`
                          : isSaturday
                          ? `Day ${day} - Saturday (School Working Day)`
                          : `Day ${day}`
                      }
                      className={`py-1.5 px-0.5 text-center w-8 font-mono tabular-nums border-r border-slate-200/60 ${
                        isSunday
                          ? 'bg-rose-50 text-rose-500 font-bold'
                          : isSaturday
                          ? 'bg-amber-50 text-amber-900 font-bold'
                          : 'text-slate-700'
                      }`}
                    >
                      <div>{day}</div>
                      <div className="text-[8px] font-sans font-normal opacity-80 uppercase tracking-tighter">
                        {isSunday ? 'Su' : isSaturday ? 'Sa' : ''}
                      </div>
                    </th>
                  );
                })}
                <th className="py-2.5 px-2 text-center text-emerald-800 font-bold w-12 border-l border-slate-200">P</th>
                <th className="py-2.5 px-2 text-center text-rose-800 font-bold w-12">A</th>
                <th className="py-2.5 px-2 text-center text-amber-800 font-bold w-12">L</th>
                <th className="py-2.5 px-2 text-center text-indigo-800 font-bold w-12">Lv</th>
                <th className="py-2.5 px-3 text-right font-bold w-16">Rate %</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {monthlySummaries.map((summary) => {
                const isAtRisk = summary.attendancePercentage < 75;

                return (
                  <tr key={summary.student.id} className="hover:bg-slate-50/80 transition-colors">
                    {/* Sticky Roll Number */}
                    <td className="py-2 px-3 sticky left-0 bg-white hover:bg-slate-50 font-mono font-bold text-slate-900 border-r border-slate-200 tabular-nums">
                      #{summary.student.roll_number}
                    </td>

                    {/* Sticky Student Name */}
                    <td className="py-2 px-3 sticky left-14 bg-white hover:bg-slate-50 border-r border-slate-200">
                      <div className="font-semibold text-slate-900 truncate max-w-44">{summary.student.name}</div>
                    </td>

                    {/* Day Cells 1..31 */}
                    {daysArray.map((day) => {
                      const dateObj = new Date(selectedYear, selectedMonth, day);
                      const dayOfWeek = dateObj.getDay();
                      const isSunday = dayOfWeek === 0;
                      const isSaturday = dayOfWeek === 6;
                      const status = summary.dailyStatus[day];

                      // Sunday is strictly a school holiday
                      if (isSunday) {
                        return (
                          <td
                            key={day}
                            title="Sunday: School Holiday (School Closed)"
                            className="py-2 px-1 text-center font-mono text-[11px] font-bold text-rose-400 bg-rose-50/40 border-r border-slate-100 select-none"
                          >
                            -
                          </td>
                        );
                      }

                      if (!status) {
                        return (
                          <td
                            key={day}
                            className={`py-2 px-1 text-center font-mono text-[10px] border-r border-slate-100 ${
                              isSaturday ? 'bg-amber-50/20 text-slate-400' : 'text-slate-300'
                            }`}
                          >
                            ·
                          </td>
                        );
                      }

                      if (status === 'present') {
                        return (
                          <td
                            key={day}
                            title={isSaturday ? 'Saturday: Present' : 'Present'}
                            className={`py-2 px-1 text-center font-bold border-r border-slate-100 text-[11px] ${
                              isSaturday
                                ? 'text-emerald-800 bg-amber-50/60'
                                : 'text-emerald-700 bg-emerald-50/40'
                            }`}
                          >
                            P
                          </td>
                        );
                      }

                      if (status === 'absent') {
                        return (
                          <td
                            key={day}
                            className="py-2 px-1 text-center font-bold text-rose-700 bg-rose-50/70 border-r border-slate-100 text-[11px]"
                          >
                            A
                          </td>
                        );
                      }

                      if (status === 'late') {
                        return (
                          <td
                            key={day}
                            className="py-2 px-1 text-center font-bold text-amber-700 bg-amber-50/50 border-r border-slate-100 text-[11px]"
                          >
                            L
                          </td>
                        );
                      }

                      if (status === 'leave') {
                        return (
                          <td
                            key={day}
                            className="py-2 px-1 text-center font-bold text-indigo-700 bg-indigo-50/50 border-r border-slate-100 text-[11px]"
                          >
                            Lv
                          </td>
                        );
                      }

                      return <td key={day} className="py-2 px-1 text-center border-r border-slate-100">-</td>;
                    })}

                    {/* Summary Counts */}
                    <td className="py-2 px-2 text-center font-mono font-semibold text-emerald-700 border-l border-slate-200 tabular-nums">
                      {summary.totalPresent}
                    </td>
                    <td className="py-2 px-2 text-center font-mono font-semibold text-rose-700 tabular-nums">
                      {summary.totalAbsent}
                    </td>
                    <td className="py-2 px-2 text-center font-mono font-semibold text-amber-700 tabular-nums">
                      {summary.totalLate}
                    </td>
                    <td className="py-2 px-2 text-center font-mono font-semibold text-indigo-700 tabular-nums">
                      {summary.totalLeave}
                    </td>

                    {/* Rate Percentage */}
                    <td className="py-2 px-3 text-right font-mono font-bold tabular-nums">
                      <span
                        className={
                          isAtRisk
                            ? 'text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded'
                            : 'text-slate-900'
                        }
                      >
                        {summary.attendancePercentage}%
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
