import React, { useState, useMemo } from 'react';
import {
  Calendar,
  Search,
  CheckCircle2,
  XCircle,
  Clock,
  FileText,
  Download,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Save,
  Check,
  User,
} from 'lucide-react';
import { Student, AttendanceRecord, AttendanceStatus, TeacherUser } from '../types';
import { exportDailyAttendanceCsv } from '../lib/csvExport';
import { ALL_CLASSES, isSeniorClass, getAvailableSectionsOrStreams } from '../lib/schoolStructure';

interface Props {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
  onSaveAttendance: (records: Array<{ studentId: string; status: AttendanceStatus; remarks?: string }>, dateStr: string) => Promise<void>;
  currentTeacher: TeacherUser | null;
  onNavigateToStudents: () => void;
}

export const DailyAttendanceView: React.FC<Props> = ({
  students,
  attendanceRecords,
  onSaveAttendance,
  currentTeacher,
  onNavigateToStudents,
}) => {
  // Filters
  const [selectedGrade, setSelectedGrade] = useState<string>(currentTeacher?.assigned_class || 'Class 10');
  const [selectedSection, setSelectedSection] = useState<string>(currentTeacher?.assigned_section || 'A');
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });
  const [searchQuery, setSearchQuery] = useState('');

  // Check if current date is Saturday
  const isSelectedSaturday = useMemo(() => {
    const parts = selectedDate.split('-');
    if (parts.length === 3) {
      const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
      return d.getDay() === 6;
    }
    return false;
  }, [selectedDate]);

  // Check if current date is Sunday (Holiday - not present, not absent)
  const isSelectedSunday = useMemo(() => {
    const parts = selectedDate.split('-');
    if (parts.length === 3) {
      const d = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
      return d.getDay() === 0;
    }
    return false;
  }, [selectedDate]);

  const handleJumpToSaturday = () => {
    const d = new Date();
    const currentDay = d.getDay();
    // If today is Saturday, keep today; otherwise get previous Saturday
    const daysToSub = currentDay === 6 ? 0 : (currentDay + 1);
    d.setDate(d.getDate() - daysToSub);
    setSelectedDate(d.toISOString().split('T')[0]);
    setLocalStatuses({});
    setLocalRemarks({});
  };

  // Local draft of roll call modifications before or during auto-save
  const [localStatuses, setLocalStatuses] = useState<Record<string, AttendanceStatus>>({});
  const [localRemarks, setLocalRemarks] = useState<Record<string, string>>({});
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Extract existing attendance records for the selected date
  const recordsMap = useMemo(() => {
    const map = new Map<string, AttendanceRecord>();
    attendanceRecords.forEach((r) => {
      if (r.date === selectedDate) {
        map.set(r.student_id, r);
      }
    });
    return map;
  }, [attendanceRecords, selectedDate]);

  // Unique grades (Class 1 to 12 prioritized)
  const availableGrades = useMemo(() => {
    const existing = students.map((s) => s.grade);
    const combined = Array.from(new Set([...ALL_CLASSES, ...existing]));
    return combined;
  }, [students]);

  const isSenior = isSeniorClass(selectedGrade);

  // Sections or Streams available for the selected grade
  const availableSections = useMemo(() => {
    if (selectedGrade === 'ALL') {
      const set = new Set(students.map((s) => s.section));
      return Array.from(set);
    }
    const defaultSections = getAvailableSectionsOrStreams(selectedGrade);
    const fromStudents = students.filter((s) => s.grade === selectedGrade).map((s) => s.section);
    return Array.from(new Set([...defaultSections, ...fromStudents]));
  }, [students, selectedGrade]);

  // Filter students by selected Grade, Section, and Search
  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      const matchGrade = selectedGrade === 'ALL' || s.grade === selectedGrade;
      const matchSec = selectedSection === 'ALL' || s.section === selectedSection;
      const matchSearch =
        searchQuery.trim() === '' ||
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.roll_number.toLowerCase().includes(searchQuery.toLowerCase());
      return matchGrade && matchSec && matchSearch;
    });
  }, [students, selectedGrade, selectedSection, searchQuery]);

  // Resolve status for student: draft status > existing record status > default 'present'
  const getStudentStatus = (studentId: string): AttendanceStatus => {
    if (localStatuses[studentId]) return localStatuses[studentId];
    const rec = recordsMap.get(studentId);
    if (rec) return rec.status;
    return 'present'; // Default assumption for school roll calls
  };

  const getStudentRemarks = (studentId: string): string => {
    if (localRemarks[studentId] !== undefined) return localRemarks[studentId];
    const rec = recordsMap.get(studentId);
    return rec?.remarks || '';
  };

  // Status statistics for currently filtered class on selected date
  const stats = useMemo(() => {
    let p = 0;
    let a = 0;
    let l = 0;
    let lv = 0;

    filteredStudents.forEach((student) => {
      const st = getStudentStatus(student.id);
      if (st === 'present') p++;
      else if (st === 'absent') a++;
      else if (st === 'late') l++;
      else if (st === 'leave') lv++;
    });

    const total = filteredStudents.length;
    const rate = total > 0 ? Math.round(((p + l) / total) * 100) : 0;
    return { total, present: p, absent: a, late: l, leave: lv, rate };
  }, [filteredStudents, recordsMap, localStatuses]);

  // Update status for a student (disabled on Sunday holiday)
  const handleStatusChange = (studentId: string, newStatus: AttendanceStatus) => {
    if (isSelectedSunday) return; // Sunday is holiday: not present, not absent
    setLocalStatuses((prev) => ({ ...prev, [studentId]: newStatus }));
    setSaveSuccess(false);
  };

  // Update remarks
  const handleRemarksChange = (studentId: string, remarks: string) => {
    if (isSelectedSunday) return;
    setLocalRemarks((prev) => ({ ...prev, [studentId]: remarks }));
    setSaveSuccess(false);
  };

  // Bulk actions (disabled on Sunday holiday)
  const handleMarkAll = (status: AttendanceStatus) => {
    if (isSelectedSunday) return; // Sunday is holiday: not present, not absent
    const next: Record<string, AttendanceStatus> = { ...localStatuses };
    filteredStudents.forEach((s) => {
      next[s.id] = status;
    });
    setLocalStatuses(next);
    setSaveSuccess(false);
  };

  // Save changes
  const handleSaveAll = async () => {
    if (isSelectedSunday) {
      return;
    }
    setIsSaving(true);
    setSaveSuccess(false);

    const payload = filteredStudents.map((s) => ({
      studentId: s.id,
      status: getStudentStatus(s.id),
      remarks: getStudentRemarks(s.id),
    }));

    await onSaveAttendance(payload, selectedDate);
    setIsSaving(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  // Date navigation helpers
  const handlePrevDay = () => {
    const cur = new Date(selectedDate);
    cur.setDate(cur.getDate() - 1);
    setSelectedDate(cur.toISOString().split('T')[0]);
    setLocalStatuses({});
    setLocalRemarks({});
  };

  const handleNextDay = () => {
    const cur = new Date(selectedDate);
    cur.setDate(cur.getDate() + 1);
    setSelectedDate(cur.toISOString().split('T')[0]);
    setLocalStatuses({});
    setLocalRemarks({});
  };

  const handleToday = () => {
    setSelectedDate(new Date().toISOString().split('T')[0]);
    setLocalStatuses({});
    setLocalRemarks({});
  };

  // Export Daily Roll Call
  const handleExportCsv = () => {
    const exportMap = new Map<string, AttendanceRecord>();
    filteredStudents.forEach((s) => {
      exportMap.set(s.id, {
        id: `att-${s.id}-${selectedDate}`,
        student_id: s.id,
        date: selectedDate,
        status: getStudentStatus(s.id),
        remarks: getStudentRemarks(s.id),
        marked_by_teacher_name: currentTeacher?.name,
        updated_at: new Date().toISOString(),
      });
    });

    exportDailyAttendanceCsv(filteredStudents, exportMap, selectedDate, selectedGrade, selectedSection);
  };

  return (
    <div className="space-y-6">
      {/* Top Filter and Controls Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Class and Section Selectors */}
          <div className="flex flex-wrap items-center gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Class (1 to 12)</label>
              <select
                value={selectedGrade}
                onChange={(e) => {
                  const newGrade = e.target.value;
                  setSelectedGrade(newGrade);
                  setSelectedSection('ALL');
                  setLocalStatuses({});
                  setLocalRemarks({});
                }}
                className="px-3 py-1.5 text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              >
                {availableGrades.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
                <option value="ALL">All Classes</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                {isSenior ? 'Stream (Science/Comm/Hum)' : 'Section'}
              </label>
              <select
                value={selectedSection}
                onChange={(e) => {
                  setSelectedSection(e.target.value);
                  setLocalStatuses({});
                  setLocalRemarks({});
                }}
                className="px-3 py-1.5 text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium"
              >
                <option value="ALL">{isSenior ? 'All Streams' : 'All Sections'}</option>
                {availableSections.map((sec) => (
                  <option key={sec} value={sec}>
                    {isSenior ? `${sec} Stream` : `Section ${sec}`}
                  </option>
                ))}
              </select>
            </div>

            {/* Date Navigator */}
            <div>
              <div className="flex items-center gap-1.5 mb-1">
                <label className="text-[11px] font-semibold text-slate-500">Attendance Date</label>
                {isSelectedSaturday && (
                  <span className="text-[10px] font-bold text-amber-900 bg-amber-100 px-1.5 py-0.2 rounded border border-amber-300">
                    Saturday Working Day
                  </span>
                )}
                {isSelectedSunday && (
                  <span className="text-[10px] font-bold text-rose-800 bg-rose-100 px-1.5 py-0.2 rounded border border-rose-300">
                    Sunday Holiday (School Closed)
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1 bg-slate-50 border border-slate-300 rounded-lg p-0.5">
                <button
                  type="button"
                  onClick={handlePrevDay}
                  title="Previous Day"
                  className="p-1 text-slate-600 hover:text-slate-900 rounded hover:bg-slate-200 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => {
                    setSelectedDate(e.target.value);
                    setLocalStatuses({});
                    setLocalRemarks({});
                  }}
                  className="px-2 py-1 text-xs font-mono font-medium text-slate-800 bg-transparent border-0 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={handleNextDay}
                  title="Next Day"
                  className="p-1 text-slate-600 hover:text-slate-900 rounded hover:bg-slate-200 transition-colors"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={handleToday}
                  className="px-2 py-1 text-[11px] font-medium text-indigo-700 hover:bg-indigo-50 rounded transition-colors"
                >
                  Today
                </button>
                <button
                  type="button"
                  onClick={handleJumpToSaturday}
                  title="Select Saturday"
                  className={`px-2 py-1 text-[11px] font-semibold rounded transition-colors border ${
                    isSelectedSaturday
                      ? 'text-amber-900 bg-amber-200 border-amber-400 font-bold'
                      : 'text-amber-800 bg-amber-50 hover:bg-amber-100 border-amber-200'
                  }`}
                >
                  Saturday
                </button>
              </div>
            </div>

            {/* Teacher Name */}
            <div>
              <span className="block text-[11px] font-semibold text-slate-500 mb-1">Teacher</span>
              <div className="px-3 py-1.5 text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg text-slate-800 flex items-center gap-1.5 h-[34px]">
                <User className="w-3.5 h-3.5 text-slate-500" />
                <span>{currentTeacher?.name || 'Omorjit Singha'}</span>
              </div>
            </div>
          </div>

          {/* Quick Actions & CSV */}
          <div className="flex items-center gap-2.5 self-end lg:self-auto">
            <button
              onClick={handleExportCsv}
              className="px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors flex items-center gap-1.5 shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              Export CSV
            </button>
            {!isSelectedSunday && (
              <button
                onClick={handleSaveAll}
                disabled={isSaving}
                className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 shrink-0 ${
                  saveSuccess
                    ? 'bg-emerald-600 text-white'
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white disabled:opacity-50'
                }`}
              >
                {saveSuccess ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    Saved
                  </>
                ) : isSaving ? (
                  'Saving...'
                ) : (
                  <>
                    <Save className="w-3.5 h-3.5" />
                    Save Roll Call
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Search & Bulk Marking Quick Buttons */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-slate-100">
          <div className="relative max-w-xs w-full">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by student name or roll..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>

          <div className="flex items-center gap-3 text-xs flex-wrap">
            <span className="text-slate-600 font-medium">
              Class Teacher: <strong className="text-slate-900">{currentTeacher?.name || 'Omorjit Singha'}</strong>
            </span>
            <span className="text-slate-300 hidden sm:inline" aria-hidden="true">|</span>
            {isSelectedSunday ? (
              <span className="text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 px-2.5 py-1 rounded-md">
                Sunday Holiday (School Closed)
              </span>
            ) : (
              <>
                <span className="text-slate-500 text-[11px]">Quick mark:</span>
                <button
                  onClick={() => handleMarkAll('present')}
                  className={`px-3 py-1 text-xs rounded-md transition-colors border shadow-xs ${
                    isSelectedSaturday
                      ? 'text-emerald-900 bg-emerald-100 hover:bg-emerald-200 border-emerald-400 font-bold'
                      : 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 font-medium'
                  }`}
                >
                  {isSelectedSaturday ? 'Saturday: All Present ✓' : 'All Present'}
                </button>
                <button
                  onClick={() => handleMarkAll('absent')}
                  className="px-2.5 py-1 text-xs font-medium text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-md transition-colors border border-rose-200"
                >
                  All Absent
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Sunday Holiday Notice Banner */}
      {isSelectedSunday && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-900 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-200 text-rose-800 flex items-center justify-center font-bold text-base shrink-0">
              ✕
            </div>
            <div>
              <h4 className="font-bold text-rose-950 text-sm">Sunday is a Weekly School Holiday</h4>
              <p className="text-rose-700 text-xs mt-0.5">
                School is closed. Students are <strong>not present</strong> and <strong>not absent</strong>. Attendance is not recorded on Sundays.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={handleJumpToSaturday}
            className="px-3.5 py-1.5 text-xs font-semibold bg-rose-600 hover:bg-rose-700 text-white rounded-lg transition-colors shrink-0"
          >
            Go to Saturday Class &rarr;
          </button>
        </div>
      )}

      {/* Attendance Statistics Summary Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-medium text-slate-500 block">Enrolled Students</span>
          <span className="text-xl font-bold text-slate-900 tabular-nums">{stats.total}</span>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-emerald-200/80 shadow-xs">
          <span className="text-[11px] font-medium text-emerald-700 block">Present</span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-emerald-700 tabular-nums">
              {isSelectedSunday ? 0 : stats.present}
            </span>
            <span className="text-xs text-slate-500 tabular-nums">
              {isSelectedSunday
                ? '(Holiday)'
                : `(${stats.total > 0 ? Math.round((stats.present / stats.total) * 100) : 0}%)`}
            </span>
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-rose-200/80 shadow-xs">
          <span className="text-[11px] font-medium text-rose-700 block">Absent</span>
          <div className="flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-rose-700 tabular-nums">
              {isSelectedSunday ? 0 : stats.absent}
            </span>
            <span className="text-xs text-slate-500 tabular-nums">
              {isSelectedSunday
                ? '(Holiday)'
                : `(${stats.total > 0 ? Math.round((stats.absent / stats.total) * 100) : 0}%)`}
            </span>
          </div>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-amber-200/80 shadow-xs">
          <span className="text-[11px] font-medium text-amber-700 block">Late</span>
          <span className="text-xl font-bold text-amber-700 tabular-nums">
            {isSelectedSunday ? 0 : stats.late}
          </span>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-indigo-200/80 shadow-xs">
          <span className="text-[11px] font-medium text-indigo-700 block">On Leave</span>
          <span className="text-xl font-bold text-indigo-700 tabular-nums">
            {isSelectedSunday ? 0 : stats.leave}
          </span>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-medium text-slate-500 block">Today's Attendance</span>
          <span className="text-xl font-bold text-indigo-900 tabular-nums">
            {isSelectedSunday ? 'Holiday' : `${stats.rate}%`}
          </span>
        </div>
      </div>

      {/* Roll Call Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        {filteredStudents.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400 mb-3">
              <Calendar className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-semibold text-slate-900">No students found</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              There are no enrolled students matching this class and section filter.
            </p>
            <button
              onClick={onNavigateToStudents}
              className="mt-4 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Add Students in Directory
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[600px] text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-600 tracking-wider">
                  <th className="py-3 px-4 w-16">Roll</th>
                  <th className="py-3 px-4">Student Details</th>
                  <th className="py-3 px-4 text-center">Mark Status</th>
                  <th className="py-3 px-4">Remarks / Note</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                {filteredStudents.map((student) => {
                  const currentStatus = getStudentStatus(student.id);
                  const currentNote = getStudentRemarks(student.id);

                  return (
                    <tr key={student.id} className="hover:bg-slate-50/60 transition-colors">
                      {/* Roll Number */}
                      <td className="py-3 px-4 font-mono font-bold text-slate-900 tabular-nums">
                        #{student.roll_number}
                      </td>

                      {/* Student Info */}
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{student.name}</div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                          <span>
                            {student.grade} - {student.section}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono">{student.guardian_phone}</span>
                        </div>
                      </td>

                      {/* Status Selector Buttons (Present / Absent / Late / Leave) */}
                      <td className="py-3 px-4">
                        {isSelectedSunday ? (
                          <div className="flex items-center justify-center">
                            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200">
                              Sunday Holiday (School Closed)
                            </span>
                          </div>
                        ) : (
                          <div className="flex items-center justify-center gap-1.5">
                            {/* Present */}
                            <button
                              type="button"
                              onClick={() => handleStatusChange(student.id, 'present')}
                              title="Mark Present"
                              className={`min-w-10 min-h-8 sm:min-w-16 px-2 sm:px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1 ${
                                currentStatus === 'present'
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              }`}
                            >
                              <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                              <span className="hidden sm:inline">Present</span>
                            </button>

                            {/* Absent */}
                            <button
                              type="button"
                              onClick={() => handleStatusChange(student.id, 'absent')}
                              title="Mark Absent"
                              className={`min-w-10 min-h-8 sm:min-w-16 px-2 sm:px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1 ${
                                currentStatus === 'absent'
                                  ? 'bg-rose-600 text-white shadow-xs'
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              }`}
                            >
                              <XCircle className="w-3.5 h-3.5 shrink-0" />
                              <span className="hidden sm:inline">Absent</span>
                            </button>

                            {/* Late */}
                            <button
                              type="button"
                              onClick={() => handleStatusChange(student.id, 'late')}
                              title="Mark Late"
                              className={`min-w-10 min-h-8 sm:min-w-16 px-2 sm:px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1 ${
                                currentStatus === 'late'
                                  ? 'bg-amber-500 text-white shadow-xs'
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              }`}
                            >
                              <Clock className="w-3.5 h-3.5 shrink-0" />
                              <span className="hidden sm:inline">Late</span>
                            </button>

                            {/* Leave */}
                            <button
                              type="button"
                              onClick={() => handleStatusChange(student.id, 'leave')}
                              title="Mark On Leave"
                              className={`min-w-10 min-h-8 sm:min-w-16 px-2 sm:px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1 ${
                                currentStatus === 'leave'
                                  ? 'bg-indigo-600 text-white shadow-xs'
                                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                              }`}
                            >
                              <FileText className="w-3.5 h-3.5 shrink-0" />
                              <span className="hidden sm:inline">Leave</span>
                            </button>
                          </div>
                        )}
                      </td>

                      {/* Remarks */}
                      <td className="py-3 px-4">
                        {isSelectedSunday ? (
                          <span className="text-xs text-slate-400 italic">Weekly Holiday · School Closed</span>
                        ) : (
                          <input
                            type="text"
                            placeholder="Add teacher remark..."
                            value={currentNote}
                            onChange={(e) => handleRemarksChange(student.id, e.target.value)}
                            className="w-full px-2.5 py-1 text-xs border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-indigo-500/30 focus:border-indigo-500 text-slate-700 bg-slate-50/50"
                          />
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
