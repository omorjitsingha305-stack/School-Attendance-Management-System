import React, { useState, useEffect } from 'react';
import {
  User,
  LogOut,
  X,
  School,
  BookOpen,
  RotateCcw,
  Edit2,
  UserPlus,
  Check,
  Users,
  Trash2,
  ArrowRight,
} from 'lucide-react';
import { TeacherUser } from '../types';
import {
  logoutTeacher,
  resetToSampleData,
  updateTeacherProfile,
  addTeacher,
  getAllTeachers,
  deleteTeacher,
  switchTeacher,
} from '../lib/storage';
import { ALL_CLASSES, isSeniorClass, getAvailableSectionsOrStreams } from '../lib/schoolStructure';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  teacher: TeacherUser | null;
  onLoggedOut: () => void;
  onDataReset: () => void;
  onTeacherUpdated: (updated: TeacherUser) => void;
  isSupabaseMode: boolean;
}

export const TeacherProfileModal: React.FC<Props> = ({
  isOpen,
  onClose,
  teacher,
  onLoggedOut,
  onDataReset,
  onTeacherUpdated,
  isSupabaseMode,
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'staff'>('profile');
  const [isEditing, setIsEditing] = useState(false);
  const [isAddingNew, setIsAddingNew] = useState(false);

  // Edit current teacher state
  const [name, setName] = useState('');
  const [role, setRole] = useState<'Class Teacher' | 'Subject Teacher' | 'Head of Department' | 'Principal'>('Class Teacher');
  const [assignedClass, setAssignedClass] = useState('Class 10');
  const [assignedSection, setAssignedSection] = useState('A');
  const [schoolName, setSchoolName] = useState('PM Shri Kendriya Vidyalaya Masimpur');
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Add new teacher state
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState<'Class Teacher' | 'Subject Teacher' | 'Head of Department' | 'Principal'>('Class Teacher');
  const [newClass, setNewClass] = useState('Class 10');
  const [newSection, setNewSection] = useState('A');
  const [addError, setAddError] = useState<string | null>(null);

  // Teachers list
  const [staffList, setStaffList] = useState<TeacherUser[]>([]);

  useEffect(() => {
    if (teacher) {
      setName(teacher.name);
      setRole(teacher.role);
      setAssignedClass(teacher.assigned_class);
      setAssignedSection(teacher.assigned_section);
      setSchoolName(teacher.school_name);
    }
    setStaffList(getAllTeachers());
    setIsEditing(false);
    setIsAddingNew(false);
    setSaveSuccess(false);
    setAddError(null);
  }, [teacher, isOpen]);

  if (!isOpen || !teacher) return null;

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setSaving(true);
    const updated = await updateTeacherProfile(teacher.id, {
      name: name.trim(),
      role,
      assigned_class: assignedClass,
      assigned_section: assignedSection,
      school_name: schoolName.trim(),
    });

    setSaving(false);
    setSaveSuccess(true);
    setIsEditing(false);
    onTeacherUpdated(updated);
    setStaffList(getAllTeachers());
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handleAddNewTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newEmail.trim()) {
      setAddError('Teacher name and email are required.');
      return;
    }

    setSaving(true);
    setAddError(null);

    const created = await addTeacher({
      name: newName.trim(),
      email: newEmail.trim().toLowerCase(),
      role: newRole,
      assigned_class: newClass,
      assigned_section: newSection,
      school_name: schoolName,
    });

    setSaving(false);
    setNewName('');
    setNewEmail('');
    setIsAddingNew(false);
    setStaffList(getAllTeachers());
    // Auto switch to newly added teacher
    onTeacherUpdated(created);
  };

  const handleSwitchTeacher = (targetId: string) => {
    const switched = switchTeacher(targetId);
    if (switched) {
      onTeacherUpdated(switched);
    }
  };

  const handleDeleteTeacher = async (targetId: string, targetName: string) => {
    if (window.confirm(`Are you sure you want to remove teacher "${targetName}" from the staff roster?`)) {
      const ok = await deleteTeacher(targetId);
      if (ok) {
        setStaffList(getAllTeachers());
        const cur = getAllTeachers()[0];
        if (cur) onTeacherUpdated(cur);
      }
    }
  };

  const handleLogout = async () => {
    await logoutTeacher();
    onLoggedOut();
    onClose();
  };

  const handleResetData = () => {
    if (
      window.confirm(
        'Reset local school attendance to original sample roster? Any new test entries in local storage will be replaced with fresh sample data.'
      )
    ) {
      resetToSampleData();
      onDataReset();
      onClose();
    }
  };

  const isCurrentSenior = isSeniorClass(assignedClass);
  const currentSections = getAvailableSectionsOrStreams(assignedClass);

  const isNewSenior = isSeniorClass(newClass);
  const newSections = getAvailableSectionsOrStreams(newClass);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="relative w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold">
              <User className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">School & Staff Portal</h2>
              <p className="text-[11px] text-slate-500">PM Shri Kendriya Vidyalaya Masimpur</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex border-b border-slate-200 px-6 bg-white gap-6 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('profile')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'profile'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            School Settings
          </button>
          <button
            onClick={() => setActiveTab('staff')}
            className={`py-3 border-b-2 transition-colors ${
              activeTab === 'staff'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Staff Directory ({staffList.length})
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-4">
          {saveSuccess && (
            <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800 text-xs flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Teacher name and profile updated successfully!</span>
            </div>
          )}

          {activeTab === 'profile' && (
            <>
              {!isEditing ? (
                /* Read View with Edit Name button */
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-lg">
                        {teacher.name.charAt(0)}
                      </div>
                      <div>
                        <h3 className="text-base font-bold text-slate-900">{teacher.name}</h3>
                        <p className="text-xs text-slate-500 font-mono">{teacher.email}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setIsEditing(true)}
                      className="px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors flex items-center gap-1.5 border border-indigo-200"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      Edit Name / Details
                    </button>
                  </div>

                  <div className="space-y-2.5 text-xs text-slate-600">
                    <div className="flex items-center justify-between py-1 border-b border-slate-100">
                      <span className="flex items-center gap-1.5 text-slate-500">
                        <School className="w-3.5 h-3.5" /> School Name
                      </span>
                      <span className="font-medium text-slate-900">{teacher.school_name}</span>
                    </div>

                    <div className="flex items-center justify-between py-1 border-b border-slate-100">
                      <span className="flex items-center gap-1.5 text-slate-500">
                        <BookOpen className="w-3.5 h-3.5" /> Assigned Class & Section/Stream
                      </span>
                      <span className="font-semibold text-slate-900">
                        {teacher.assigned_class} - {teacher.assigned_section}
                      </span>
                    </div>

                    <div className="flex items-center justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Role Designation</span>
                      <span className="font-medium text-slate-900">{teacher.role}</span>
                    </div>

                    <div className="flex items-center justify-between py-1">
                      <span className="text-slate-500">Database Engine</span>
                      <span className="font-medium text-indigo-700">
                        {isSupabaseMode ? 'Supabase PostgreSQL Cloud' : 'Shared School Database'}
                      </span>
                    </div>
                  </div>

                  <div className="pt-3 space-y-2 border-t border-slate-100">
                    <button
                      onClick={handleResetData}
                      className="w-full py-2 px-3 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors flex items-center justify-center gap-1.5"
                    >
                      <RotateCcw className="w-3.5 h-3.5" /> Reset Local Sample Data
                    </button>

                    <button
                      onClick={handleLogout}
                      className="w-full py-2 px-3 text-xs font-semibold text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-lg transition-colors flex items-center justify-center gap-1.5"
                    >
                      <LogOut className="w-3.5 h-3.5" /> Sign Out
                    </button>
                  </div>
                </div>
              ) : (
                /* Edit Form */
                <form onSubmit={handleSaveProfile} className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Teacher Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Omorjit Singha"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      School / Institution Name
                    </label>
                    <input
                      type="text"
                      required
                      value={schoolName}
                      onChange={(e) => setSchoolName(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Class (1 to 12)
                      </label>
                      <select
                        value={assignedClass}
                        onChange={(e) => {
                          const next = e.target.value;
                          setAssignedClass(next);
                          const avail = getAvailableSectionsOrStreams(next);
                          if (!avail.includes(assignedSection)) {
                            setAssignedSection(avail[0]);
                          }
                        }}
                        className="w-full px-2.5 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                      >
                        {ALL_CLASSES.map((c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        {isCurrentSenior ? 'Stream' : 'Section'}
                      </label>
                      <select
                        value={assignedSection}
                        onChange={(e) => setAssignedSection(e.target.value)}
                        className="w-full px-2.5 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium"
                      >
                        {currentSections.map((opt) => (
                          <option key={opt} value={opt}>
                            {isCurrentSenior ? `${opt} Stream` : `Section ${opt}`}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Role Designation
                    </label>
                    <select
                      value={role}
                      onChange={(e) => setRole(e.target.value as any)}
                      className="w-full px-2.5 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    >
                      <option value="Class Teacher">Class Teacher</option>
                      <option value="Subject Teacher">Subject Teacher</option>
                      <option value="Head of Department">Head of Department</option>
                      <option value="Principal">Principal / Headmaster</option>
                    </select>
                  </div>

                  <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setIsEditing(false)}
                      className="px-3 py-1.5 text-xs font-medium text-slate-600 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={saving}
                      className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors flex items-center gap-1.5 disabled:opacity-50"
                    >
                      <Check className="w-3.5 h-3.5" />
                      Save Name & Details
                    </button>
                  </div>
                </form>
              )}
            </>
          )}

          {activeTab === 'staff' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Faculty Members</h4>
                  <p className="text-[11px] text-slate-500">Switch session or add a new teacher</p>
                </div>
                {!isAddingNew && (
                  <button
                    onClick={() => setIsAddingNew(true)}
                    className="px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors flex items-center gap-1.5"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                    + Add New Teacher
                  </button>
                )}
              </div>

              {isAddingNew && (
                <form
                  onSubmit={handleAddNewTeacher}
                  className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <h5 className="text-xs font-bold text-slate-900">Enroll New Teacher</h5>
                    <button
                      type="button"
                      onClick={() => setIsAddingNew(false)}
                      className="text-slate-400 hover:text-slate-600 text-xs"
                    >
                      Cancel
                    </button>
                  </div>

                  {addError && (
                    <div className="p-2 bg-rose-50 border border-rose-200 rounded text-rose-700 text-xs">
                      {addError}
                    </div>
                  )}

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Teacher Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Dr. Arthur Pendelton"
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="arthur.pendelton@school.edu"
                      value={newEmail}
                      onChange={(e) => setNewEmail(e.target.value)}
                      className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-mono"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        Class
                      </label>
                      <select
                        value={newClass}
                        onChange={(e) => {
                          const next = e.target.value;
                          setNewClass(next);
                          const avail = getAvailableSectionsOrStreams(next);
                          if (!avail.includes(newSection)) {
                            setNewSection(avail[0]);
                          }
                        }}
                        className="w-full px-2 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                      >
                        {ALL_CLASSES.map((c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                        {isNewSenior ? 'Stream' : 'Section'}
                      </label>
                      <select
                        value={newSection}
                        onChange={(e) => setNewSection(e.target.value)}
                        className="w-full px-2 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                      >
                        {newSections.map((opt) => (
                          <option key={opt} value={opt}>
                            {isNewSenior ? `${opt} Stream` : `Section ${opt}`}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Role
                    </label>
                    <select
                      value={newRole}
                      onChange={(e) => setNewRole(e.target.value as any)}
                      className="w-full px-2 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                    >
                      <option value="Class Teacher">Class Teacher</option>
                      <option value="Subject Teacher">Subject Teacher</option>
                      <option value="Head of Department">Head of Department</option>
                      <option value="Principal">Principal</option>
                    </select>
                  </div>

                  <div className="pt-2 flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setIsAddingNew(false)}
                      className="px-3 py-1.5 text-xs font-medium text-slate-600 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={saving}
                      className="px-4 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg"
                    >
                      Add & Select Teacher
                    </button>
                  </div>
                </form>
              )}

              {/* Roster of teachers */}
              <div className="space-y-2">
                {staffList.map((st) => {
                  const isCurrent = st.id === teacher.id;
                  return (
                    <div
                      key={st.id}
                      className={`p-3 rounded-lg border flex items-center justify-between gap-3 transition-colors ${
                        isCurrent
                          ? 'bg-indigo-50/70 border-indigo-200'
                          : 'bg-white border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                            isCurrent
                              ? 'bg-indigo-600 text-white'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {st.name.charAt(0)}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-bold text-slate-900">{st.name}</span>
                            {isCurrent && (
                              <span className="text-[10px] font-semibold text-indigo-700 bg-indigo-100 px-1.5 py-0.2 rounded">
                                Active Session
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-500">
                            {st.role} · {st.assigned_class} ({st.assigned_section})
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        {!isCurrent && (
                          <button
                            type="button"
                            onClick={() => handleSwitchTeacher(st.id)}
                            className="px-2.5 py-1 text-xs font-semibold text-slate-700 hover:text-indigo-600 bg-white border border-slate-200 hover:border-indigo-300 rounded-md transition-colors flex items-center gap-1"
                          >
                            Switch <ArrowRight className="w-3 h-3" />
                          </button>
                        )}
                        {staffList.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleDeleteTeacher(st.id, st.name)}
                            title="Remove teacher"
                            className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
