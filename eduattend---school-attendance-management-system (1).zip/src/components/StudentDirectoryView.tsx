import React, { useState, useMemo } from 'react';
import { Plus, Search, Edit2, Trash2, Download, Phone, Mail, UserPlus, Users } from 'lucide-react';
import { Student, TeacherUser } from '../types';
import { exportStudentRosterCsv } from '../lib/csvExport';
import { ALL_CLASSES, isSeniorClass, getAvailableSectionsOrStreams } from '../lib/schoolStructure';

interface Props {
  students: Student[];
  onOpenAddModal: () => void;
  onOpenEditModal: (student: Student) => void;
  onDeleteStudent: (studentId: string) => Promise<void>;
  currentTeacher?: TeacherUser | null;
}

export const StudentDirectoryView: React.FC<Props> = ({
  students,
  onOpenAddModal,
  onOpenEditModal,
  onDeleteStudent,
  currentTeacher,
}) => {
  const [selectedGrade, setSelectedGrade] = useState<string>('ALL');
  const [selectedSection, setSelectedSection] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Grades & sections
  const availableGrades = useMemo(() => {
    const existing = students.map((s) => s.grade);
    return Array.from(new Set([...ALL_CLASSES, ...existing]));
  }, [students]);

  const isSenior = isSeniorClass(selectedGrade);

  const availableSections = useMemo(() => {
    if (selectedGrade === 'ALL') {
      const set = new Set(students.map((s) => s.section));
      return Array.from(set);
    }
    const defaultSections = getAvailableSectionsOrStreams(selectedGrade);
    const list = students.filter((s) => s.grade === selectedGrade).map((s) => s.section);
    return Array.from(new Set([...defaultSections, ...list]));
  }, [students, selectedGrade]);

  // Filtered students
  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      const matchGrade = selectedGrade === 'ALL' || s.grade === selectedGrade;
      const matchSec = selectedSection === 'ALL' || s.section === selectedSection;
      const matchQuery =
        searchQuery.trim() === '' ||
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.roll_number.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (s.guardian_name && s.guardian_name.toLowerCase().includes(searchQuery.toLowerCase()));

      return matchGrade && matchSec && matchQuery;
    });
  }, [students, selectedGrade, selectedSection, searchQuery]);

  const handleDeleteConfirm = async (student: Student) => {
    if (window.confirm(`Are you sure you want to remove student "${student.name}" (Roll #${student.roll_number})? This will also remove associated attendance records.`)) {
      setDeletingId(student.id);
      try {
        await onDeleteStudent(student.id);
      } finally {
        setDeletingId(null);
      }
    }
  };

  const handleExportCsv = () => {
    exportStudentRosterCsv(filteredStudents);
  };

  return (
    <div className="space-y-6">
      {/* Top Filter and Controls Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-bold text-slate-900">Student Directory</h2>
            <p className="text-xs text-slate-500">
              Manage student enrollment, class rosters, and parent contacts
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handleExportCsv}
              className="px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              Export Roster CSV
            </button>
            <button
              onClick={onOpenAddModal}
              className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              Enroll New Student
            </button>
          </div>
        </div>

        {/* Filter controls */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100">
          <div className="flex flex-wrap items-center gap-3">
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Filter by Class (1 to 12)</label>
              <select
                value={selectedGrade}
                onChange={(e) => {
                  setSelectedGrade(e.target.value);
                  setSelectedSection('ALL');
                }}
                className="px-3 py-1.5 text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              >
                <option value="ALL">All Classes ({students.length})</option>
                {availableGrades.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                {isSenior ? 'Stream (Science/Comm/Hum)' : 'Section'}
              </label>
              <select
                value={selectedSection}
                onChange={(e) => setSelectedSection(e.target.value)}
                className="px-3 py-1.5 text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-medium"
              >
                <option value="ALL">{isSenior ? 'All Streams' : 'All Sections'}</option>
                {availableSections.map((sec) => (
                  <option key={sec} value={sec}>
                    {isSenior ? `${sec} Stream` : `Section ${sec}`}
                  </option>
                ))}
              </select>
            </div>

            {/* Teacher Name */}
            <div>
              <span className="block text-[11px] font-semibold text-slate-500 mb-1">Teacher</span>
              <div className="px-3 py-1.5 text-xs font-semibold bg-slate-50 border border-slate-300 rounded-lg text-slate-800 flex items-center gap-1.5 h-[34px]">
                <span>{currentTeacher?.name || 'Omorjit Singha'}</span>
              </div>
            </div>
          </div>

          {/* Search Box */}
          <div className="relative max-w-xs w-full">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by student, roll number, or parent..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
          </div>
        </div>
      </div>

      {/* Student List Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        {filteredStudents.length === 0 ? (
          <div className="p-12 text-center">
            <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400 mb-3">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-semibold text-slate-900">No students matched</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Try adjusting your class filter or search criteria, or enroll a new student.
            </p>
            <button
              onClick={onOpenAddModal}
              className="mt-4 px-3.5 py-1.5 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors inline-flex items-center gap-1.5"
            >
              <UserPlus className="w-3.5 h-3.5" /> Enroll Student
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-600">
                  <th className="py-3 px-4 w-16">Roll</th>
                  <th className="py-3 px-4">Student Name</th>
                  <th className="py-3 px-4">Class & Section</th>
                  <th className="py-3 px-4">Gender</th>
                  <th className="py-3 px-4">Guardian Contact</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredStudents.map((student) => (
                  <tr key={student.id} className="hover:bg-slate-50/70 transition-colors">
                    {/* Roll */}
                    <td className="py-3 px-4 font-mono font-bold text-slate-900 tabular-nums">
                      #{student.roll_number}
                    </td>

                    {/* Name */}
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">{student.name}</div>
                      {student.email && (
                        <div className="text-[11px] text-slate-400 font-mono flex items-center gap-1 mt-0.5">
                          <Mail className="w-3 h-3" /> {student.email}
                        </div>
                      )}
                    </td>

                    {/* Class & Section */}
                    <td className="py-3 px-4 font-medium text-slate-800">
                      {student.grade} - {student.section}
                    </td>

                    {/* Gender */}
                    <td className="py-3 px-4 text-slate-600">{student.gender}</td>

                    {/* Guardian Contact */}
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-800">{student.guardian_name || 'Guardian'}</div>
                      <a
                        href={`tel:${student.guardian_phone}`}
                        className="text-[11px] text-indigo-600 hover:text-indigo-800 font-mono flex items-center gap-1 mt-0.5"
                      >
                        <Phone className="w-3 h-3" /> {student.guardian_phone}
                      </a>
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => onOpenEditModal(student)}
                          title="Edit Student Details"
                          className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          disabled={deletingId === student.id}
                          onClick={() => handleDeleteConfirm(student)}
                          title="Delete Student"
                          className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors disabled:opacity-40"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
