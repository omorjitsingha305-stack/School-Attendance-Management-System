import React, { useState } from 'react';
import { Database, Check, Copy, ExternalLink, AlertCircle, RefreshCw, X } from 'lucide-react';
import { SUPABASE_SETUP_SQL } from '../lib/supabaseSql';
import { getSavedConfig, saveSupabaseConfig, resetSupabaseConfig, testSupabaseConnection } from '../lib/supabase';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onConfigUpdated: () => void;
}

export const SupabaseSetupModal: React.FC<Props> = ({ isOpen, onClose, onConfigUpdated }) => {
  const currentConfig = getSavedConfig();
  const [url, setUrl] = useState(currentConfig.url || '');
  const [anonKey, setAnonKey] = useState(currentConfig.anonKey || '');
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [copiedSql, setCopiedSql] = useState(false);
  const [activeTab, setActiveTab] = useState<'credentials' | 'sql' | 'guide'>('credentials');

  if (!isOpen) return null;

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_SETUP_SQL);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2500);
  };

  const handleTestAndSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim() || !anonKey.trim()) {
      setTestResult({ success: false, message: 'Please enter both Supabase URL and Anon Public Key.' });
      return;
    }

    setTesting(true);
    setTestResult(null);

    const res = await testSupabaseConnection(url.trim(), anonKey.trim());
    setTesting(false);
    setTestResult(res);

    if (res.success) {
      saveSupabaseConfig(url.trim(), anonKey.trim(), true);
      onConfigUpdated();
    }
  };

  const handleResetToLocal = () => {
    resetSupabaseConfig();
    setUrl('');
    setAnonKey('');
    setTestResult({ success: true, message: 'Switched to Built-in Shared School Database mode.' });
    onConfigUpdated();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="relative w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-slate-900">Supabase Cloud Database Setup</h2>
              <p className="text-xs text-slate-500">Shared multi-teacher persistence & authentication</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-200 px-6 bg-white gap-6">
          <button
            onClick={() => setActiveTab('credentials')}
            className={`py-3 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'credentials'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            1. Connect Credentials
          </button>
          <button
            onClick={() => setActiveTab('sql')}
            className={`py-3 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'sql'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            2. SQL Schema Script
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`py-3 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'guide'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            3. Beginner Step-by-Step
          </button>
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto space-y-5 text-sm text-slate-700">
          {activeTab === 'credentials' && (
            <form onSubmit={handleTestAndSave} className="space-y-4">
              <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 text-xs leading-relaxed text-slate-600">
                <span className="font-semibold text-slate-800">Current Mode: </span>
                {currentConfig.url ? (
                  <span className="text-emerald-700 font-medium">Supabase Cloud Configured ({currentConfig.url})</span>
                ) : (
                  <span className="text-indigo-700 font-medium">
                    Built-in Shared School Database (Active with instant tab sync)
                  </span>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Supabase Project URL
                </label>
                <input
                  type="url"
                  placeholder="https://xyzcompany.supabase.co"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Supabase Anon / Public Key
                </label>
                <input
                  type="password"
                  placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                  value={anonKey}
                  onChange={(e) => setAnonKey(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 font-mono"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Found in your Supabase dashboard under: Project Settings &rarr; API &rarr; Project API keys (`anon` / public).
                </p>
              </div>

              {testResult && (
                <div
                  className={`p-3 rounded-lg text-xs flex items-start gap-2 ${
                    testResult.success
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-rose-50 text-rose-800 border border-rose-200'
                  }`}
                >
                  {testResult.success ? (
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  )}
                  <span>{testResult.message}</span>
                </div>
              )}

              <div className="pt-2 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={handleResetToLocal}
                  className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 border border-slate-300 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Use Local Shared DB
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="submit"
                    disabled={testing}
                    className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors flex items-center gap-1.5 disabled:opacity-50"
                  >
                    {testing ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        Connecting...
                      </>
                    ) : (
                      'Save & Connect Supabase'
                    )}
                  </button>
                </div>
              </div>
            </form>
          )}

          {activeTab === 'sql' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs text-slate-600">
                  Run this SQL in your Supabase project (<strong>SQL Editor</strong> &rarr; <strong>New Query</strong>) to create the schema and seed students:
                </p>
                <button
                  onClick={handleCopySql}
                  className="px-3 py-1.5 text-xs font-medium bg-slate-900 hover:bg-slate-800 text-white rounded-lg flex items-center gap-1.5 transition-colors shrink-0"
                >
                  {copiedSql ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      Copy Schema SQL
                    </>
                  )}
                </button>
              </div>

              <div className="relative bg-slate-900 text-slate-200 rounded-lg p-3.5 max-h-72 overflow-y-auto font-mono text-[11px] leading-relaxed border border-slate-800">
                <pre>{SUPABASE_SETUP_SQL}</pre>
              </div>
            </div>
          )}

          {activeTab === 'guide' && (
            <div className="space-y-4 text-xs leading-relaxed text-slate-600">
              <div className="p-3 bg-indigo-50 border border-indigo-100 rounded-lg text-indigo-900">
                <p className="font-semibold mb-1">Beginner Guide: Setting up Supabase in 3 Minutes</p>
                <p className="text-[11px]">
                  Supabase gives your school a PostgreSQL cloud database with row security so multiple teachers on different laptops/phones see live attendance records immediately.
                </p>
              </div>

              <ol className="space-y-3 list-decimal pl-4">
                <li>
                  <strong>Create Free Supabase Project</strong>: Go to{' '}
                  <a
                    href="https://supabase.com"
                    target="_blank"
                    rel="noreferrer"
                    className="text-indigo-600 font-semibold underline inline-flex items-center gap-0.5"
                  >
                    supabase.com <ExternalLink className="w-3 h-3" />
                  </a>{' '}
                  and click "New Project". Give your project a name (e.g. <code>SchoolAttendance</code>) and a database password.
                </li>
                <li>
                  <strong>Run Database Schema</strong>: In your Supabase Dashboard sidebar, click <strong>SQL Editor</strong> &rarr; <strong>+ New query</strong>. Switch to the <em>"SQL Schema Script"</em> tab above, copy the SQL, paste it in, and click <strong>Run</strong>.
                </li>
                <li>
                  <strong>Get Your API Keys</strong>: Go to <strong>Project Settings</strong> (gear icon) &rarr; <strong>API</strong>. Copy your <strong>Project URL</strong> and the <strong>anon public key</strong>.
                </li>
                <li>
                  <strong>Paste & Connect</strong>: Switch back to the <em>"Connect Credentials"</em> tab here, paste the URL and Anon Key, and click <strong>Save & Connect Supabase</strong>.
                </li>
              </ol>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
