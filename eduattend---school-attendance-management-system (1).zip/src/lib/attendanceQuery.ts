import { AttendanceRecord } from '../types';

const ATTENDANCE_KEY = 'eduattend_attendance_v3';

export function getLocalAttendanceRecords(): AttendanceRecord[] {
  try {
    const raw = localStorage.getItem(ATTENDANCE_KEY);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Failed to read attendance records:', e);
  }
  return [];
}
