import { Student, AttendanceRecord, TeacherUser } from '../types';

export const INITIAL_TEACHERS: TeacherUser[] = [
  {
    id: 't-101',
    email: 'omorjitsingha305@gmail.com',
    name: 'Omorjit Singha',
    role: 'Class Teacher',
    assigned_class: 'Class 10',
    assigned_section: 'A',
    school_name: 'PM Shri Kendriya Vidyalaya Masimpur',
  },
  {
    id: 't-102',
    email: 'eleanor.vance@westlake.edu',
    name: 'Dr. Eleanor Vance',
    role: 'Head of Department',
    assigned_class: 'Class 11',
    assigned_section: 'Science',
    school_name: 'PM Shri Kendriya Vidyalaya Masimpur',
  },
  {
    id: 't-103',
    email: 'vikram.seth@westlake.edu',
    name: 'Prof. Vikram Seth',
    role: 'Class Teacher',
    assigned_class: 'Class 11',
    assigned_section: 'Humanities',
    school_name: 'PM Shri Kendriya Vidyalaya Masimpur',
  },
  {
    id: 't-104',
    email: 'marcus.aurelius@westlake.edu',
    name: 'Marcus Bell',
    role: 'Class Teacher',
    assigned_class: 'Class 12',
    assigned_section: 'Commerce',
    school_name: 'PM Shri Kendriya Vidyalaya Masimpur',
  },
  {
    id: 't-105',
    email: 'emily.clarke@westlake.edu',
    name: 'Emily Clarke',
    role: 'Class Teacher',
    assigned_class: 'Class 1',
    assigned_section: 'A',
    school_name: 'PM Shri Kendriya Vidyalaya Masimpur',
  },
];

export const INITIAL_STUDENTS: Student[] = [
  // Class 1
  {
    id: 's-c1-01',
    roll_number: '101',
    name: 'Leo Anderson',
    grade: 'Class 1',
    section: 'A',
    gender: 'Male',
    guardian_name: 'Arthur Anderson',
    guardian_phone: '+1 (555) 111-2201',
    admission_date: '2026-04-01',
    created_at: new Date('2026-04-01').toISOString(),
  },
  {
    id: 's-c1-02',
    roll_number: '102',
    name: 'Aria Sharma',
    grade: 'Class 1',
    section: 'A',
    gender: 'Female',
    guardian_name: 'Pooja Sharma',
    guardian_phone: '+1 (555) 111-2202',
    admission_date: '2026-04-01',
    created_at: new Date('2026-04-01').toISOString(),
  },
  // Class 2
  {
    id: 's-c2-01',
    roll_number: '101',
    name: 'Oliver Twist',
    grade: 'Class 2',
    section: 'A',
    gender: 'Male',
    guardian_name: 'Rose Brown',
    guardian_phone: '+1 (555) 111-2203',
    admission_date: '2025-04-01',
    created_at: new Date('2025-04-01').toISOString(),
  },
  {
    id: 's-c2-02',
    roll_number: '102',
    name: 'Chloe Bennett',
    grade: 'Class 2',
    section: 'A',
    gender: 'Female',
    guardian_name: 'George Bennett',
    guardian_phone: '+1 (555) 111-2204',
    admission_date: '2025-04-01',
    created_at: new Date('2025-04-01').toISOString(),
  },
  // Class 3
  {
    id: 's-c3-01',
    roll_number: '101',
    name: 'Mason Davis',
    grade: 'Class 3',
    section: 'A',
    gender: 'Male',
    guardian_name: 'William Davis',
    guardian_phone: '+1 (555) 111-2205',
    admission_date: '2024-04-01',
    created_at: new Date('2024-04-01').toISOString(),
  },
  // Class 4
  {
    id: 's-c4-01',
    roll_number: '101',
    name: 'Ella Scott',
    grade: 'Class 4',
    section: 'A',
    gender: 'Female',
    guardian_name: 'Clara Scott',
    guardian_phone: '+1 (555) 111-2206',
    admission_date: '2023-04-01',
    created_at: new Date('2023-04-01').toISOString(),
  },
  // Class 5
  {
    id: 's-c5-01',
    roll_number: '101',
    name: 'Lucas Green',
    grade: 'Class 5',
    section: 'A',
    gender: 'Male',
    guardian_name: 'Richard Green',
    guardian_phone: '+1 (555) 111-2207',
    admission_date: '2022-04-01',
    created_at: new Date('2022-04-01').toISOString(),
  },
  // Class 6
  {
    id: 's-c6-01',
    roll_number: '101',
    name: 'Hannah Abbott',
    grade: 'Class 6',
    section: 'A',
    gender: 'Female',
    guardian_name: 'Philip Abbott',
    guardian_phone: '+1 (555) 111-2208',
    admission_date: '2021-04-01',
    created_at: new Date('2021-04-01').toISOString(),
  },
  // Class 7
  {
    id: 's-c7-01',
    roll_number: '101',
    name: 'Jack Wilson',
    grade: 'Class 7',
    section: 'A',
    gender: 'Male',
    guardian_name: 'Daniel Wilson',
    guardian_phone: '+1 (555) 111-2209',
    admission_date: '2020-04-01',
    created_at: new Date('2020-04-01').toISOString(),
  },
  // Class 8
  {
    id: 's-c8-01',
    roll_number: '101',
    name: 'Grace Miller',
    grade: 'Class 8',
    section: 'A',
    gender: 'Female',
    guardian_name: 'Alan Miller',
    guardian_phone: '+1 (555) 111-2210',
    admission_date: '2019-04-01',
    created_at: new Date('2019-04-01').toISOString(),
  },
  // Class 9
  {
    id: 's-301',
    roll_number: '301',
    name: 'Benjamin Hayes',
    grade: 'Class 9',
    section: 'A',
    gender: 'Male',
    guardian_name: 'George Hayes',
    guardian_phone: '+1 (555) 556-6778',
    email: 'ben.hayes@student.westlake.edu',
    admission_date: '2024-09-01',
    created_at: new Date('2024-09-01').toISOString(),
  },
  {
    id: 's-302',
    roll_number: '302',
    name: 'Harper Bailey',
    grade: 'Class 9',
    section: 'A',
    gender: 'Female',
    guardian_name: 'Laura Bailey',
    guardian_phone: '+1 (555) 667-7889',
    email: 'harper.bailey@student.westlake.edu',
    admission_date: '2024-09-01',
    created_at: new Date('2024-09-01').toISOString(),
  },
  // Class 10 - Section A
  {
    id: 's-101',
    roll_number: '101',
    name: 'Alexander Reed',
    grade: 'Class 10',
    section: 'A',
    gender: 'Male',
    guardian_name: 'Marcus Reed',
    guardian_phone: '+1 (555) 234-5678',
    email: 'alex.reed@student.westlake.edu',
    admission_date: '2024-09-01',
    created_at: new Date('2024-09-01').toISOString(),
  },
  {
    id: 's-102',
    roll_number: '102',
    name: 'Sophia Chen',
    grade: 'Class 10',
    section: 'A',
    gender: 'Female',
    guardian_name: 'Wei Chen',
    guardian_phone: '+1 (555) 345-6789',
    email: 'sophia.chen@student.westlake.edu',
    admission_date: '2024-09-01',
    created_at: new Date('2024-09-01').toISOString(),
  },
  {
    id: 's-103',
    roll_number: '103',
    name: 'Liam Vance',
    grade: 'Class 10',
    section: 'A',
    gender: 'Male',
    guardian_name: 'Sarah Vance',
    guardian_phone: '+1 (555) 456-7890',
    email: 'liam.vance@student.westlake.edu',
    admission_date: '2024-09-01',
    created_at: new Date('2024-09-01').toISOString(),
  },
  {
    id: 's-104',
    roll_number: '104',
    name: 'Emily Watson',
    grade: 'Class 10',
    section: 'A',
    gender: 'Female',
    guardian_name: 'David Watson',
    guardian_phone: '+1 (555) 567-8901',
    email: 'emily.watson@student.westlake.edu',
    admission_date: '2024-09-01',
    created_at: new Date('2024-09-01').toISOString(),
  },
  {
    id: 's-105',
    roll_number: '105',
    name: 'Noah Patel',
    grade: 'Class 10',
    section: 'A',
    gender: 'Male',
    guardian_name: 'Rajesh Patel',
    guardian_phone: '+1 (555) 678-9012',
    email: 'noah.patel@student.westlake.edu',
    admission_date: '2024-09-01',
    created_at: new Date('2024-09-01').toISOString(),
  },
  // Class 10 - Section B
  {
    id: 's-201',
    roll_number: '201',
    name: 'Lucas Garcia',
    grade: 'Class 10',
    section: 'B',
    gender: 'Male',
    guardian_name: 'Carlos Garcia',
    guardian_phone: '+1 (555) 112-2334',
    email: 'lucas.garcia@student.westlake.edu',
    admission_date: '2024-09-01',
    created_at: new Date('2024-09-01').toISOString(),
  },
  {
    id: 's-202',
    roll_number: '202',
    name: 'Mia Tanaka',
    grade: 'Class 10',
    section: 'B',
    gender: 'Female',
    guardian_name: 'Kenji Tanaka',
    guardian_phone: '+1 (555) 223-3445',
    email: 'mia.tanaka@student.westlake.edu',
    admission_date: '2024-09-01',
    created_at: new Date('2024-09-01').toISOString(),
  },

  // ========================================================
  // CLASS 11 - ALL 3 STREAMS: Science, Commerce, Humanities
  // ========================================================
  // Class 11 - Science
  {
    id: 's-11-sci-01',
    roll_number: '1101',
    name: 'Daniel Cooper',
    grade: 'Class 11',
    section: 'Science',
    gender: 'Male',
    guardian_name: 'Simon Cooper',
    guardian_phone: '+1 (555) 889-9001',
    email: 'daniel.cooper@student.westlake.edu',
    admission_date: '2025-09-01',
    created_at: new Date('2025-09-01').toISOString(),
  },
  {
    id: 's-11-sci-02',
    roll_number: '1102',
    name: 'Ella Howard',
    grade: 'Class 11',
    section: 'Science',
    gender: 'Female',
    guardian_name: 'Judith Howard',
    guardian_phone: '+1 (555) 990-0112',
    email: 'ella.howard@student.westlake.edu',
    admission_date: '2025-09-01',
    created_at: new Date('2025-09-01').toISOString(),
  },
  {
    id: 's-11-sci-03',
    roll_number: '1103',
    name: 'Rohan Verma',
    grade: 'Class 11',
    section: 'Science',
    gender: 'Male',
    guardian_name: 'Anil Verma',
    guardian_phone: '+1 (555) 990-0113',
    email: 'rohan.verma@student.westlake.edu',
    admission_date: '2025-09-01',
    created_at: new Date('2025-09-01').toISOString(),
  },
  // Class 11 - Commerce
  {
    id: 's-11-com-01',
    roll_number: '1121',
    name: 'Ananya Roy',
    grade: 'Class 11',
    section: 'Commerce',
    gender: 'Female',
    guardian_name: 'Subhash Roy',
    guardian_phone: '+1 (555) 991-0201',
    email: 'ananya.roy@student.westlake.edu',
    admission_date: '2025-09-01',
    created_at: new Date('2025-09-01').toISOString(),
  },
  {
    id: 's-11-com-02',
    roll_number: '1122',
    name: 'Marcus Brody',
    grade: 'Class 11',
    section: 'Commerce',
    gender: 'Male',
    guardian_name: 'Frank Brody',
    guardian_phone: '+1 (555) 991-0202',
    email: 'marcus.brody@student.westlake.edu',
    admission_date: '2025-09-01',
    created_at: new Date('2025-09-01').toISOString(),
  },
  // Class 11 - Humanities
  {
    id: 's-11-hum-01',
    roll_number: '1141',
    name: 'Maya Angelis',
    grade: 'Class 11',
    section: 'Humanities',
    gender: 'Female',
    guardian_name: 'Nicholas Angelis',
    guardian_phone: '+1 (555) 992-0301',
    email: 'maya.angelis@student.westlake.edu',
    admission_date: '2025-09-01',
    created_at: new Date('2025-09-01').toISOString(),
  },
  {
    id: 's-11-hum-02',
    roll_number: '1142',
    name: 'Gabriel Morales',
    grade: 'Class 11',
    section: 'Humanities',
    gender: 'Male',
    guardian_name: 'Maria Morales',
    guardian_phone: '+1 (555) 992-0302',
    email: 'gabriel.m@student.westlake.edu',
    admission_date: '2025-09-01',
    created_at: new Date('2025-09-01').toISOString(),
  },

  // ========================================================
  // CLASS 12 - ALL 3 STREAMS: Science, Commerce, Humanities
  // ========================================================
  // Class 12 - Science
  {
    id: 's-12-sci-01',
    roll_number: '1201',
    name: 'Aditya Sen',
    grade: 'Class 12',
    section: 'Science',
    gender: 'Male',
    guardian_name: 'Pradeep Sen',
    guardian_phone: '+1 (555) 993-0401',
    email: 'aditya.sen@student.westlake.edu',
    admission_date: '2024-09-01',
    created_at: new Date('2024-09-01').toISOString(),
  },
  {
    id: 's-12-sci-02',
    roll_number: '1202',
    name: 'Serena Gomez',
    grade: 'Class 12',
    section: 'Science',
    gender: 'Female',
    guardian_name: 'Lucia Gomez',
    guardian_phone: '+1 (555) 993-0402',
    email: 'serena.g@student.westlake.edu',
    admission_date: '2024-09-01',
    created_at: new Date('2024-09-01').toISOString(),
  },
  // Class 12 - Commerce
  {
    id: 's-12-com-01',
    roll_number: '1221',
    name: 'William Torres',
    grade: 'Class 12',
    section: 'Commerce',
    gender: 'Male',
    guardian_name: 'Victor Torres',
    guardian_phone: '+1 (555) 123-9876',
    email: 'william.torres@student.westlake.edu',
    admission_date: '2024-09-01',
    created_at: new Date('2024-09-01').toISOString(),
  },
  {
    id: 's-12-com-02',
    roll_number: '1222',
    name: 'Priya Narang',
    grade: 'Class 12',
    section: 'Commerce',
    gender: 'Female',
    guardian_name: 'Harish Narang',
    guardian_phone: '+1 (555) 123-9877',
    email: 'priya.narang@student.westlake.edu',
    admission_date: '2024-09-01',
    created_at: new Date('2024-09-01').toISOString(),
  },
  // Class 12 - Humanities
  {
    id: 's-12-hum-01',
    roll_number: '1241',
    name: 'Julian Thorne',
    grade: 'Class 12',
    section: 'Humanities',
    gender: 'Male',
    guardian_name: 'Julian Thorne Sr.',
    guardian_phone: '+1 (555) 994-0501',
    email: 'julian.t@student.westlake.edu',
    admission_date: '2024-09-01',
    created_at: new Date('2024-09-01').toISOString(),
  },
  {
    id: 's-12-hum-02',
    roll_number: '1242',
    name: 'Zara Al-Mansoor',
    grade: 'Class 12',
    section: 'Humanities',
    gender: 'Female',
    guardian_name: 'Tariq Al-Mansoor',
    guardian_phone: '+1 (555) 994-0502',
    email: 'zara.m@student.westlake.edu',
    admission_date: '2024-09-01',
    created_at: new Date('2024-09-01').toISOString(),
  },
];

// Helper to generate realistic historical attendance for the current month
export function generateInitialAttendance(students: Student[]): AttendanceRecord[] {
  const records: AttendanceRecord[] = [];
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth();
  const currentDay = now.getDate();

  // Generate attendance for past days in this month (Sundays are off; Saturdays are working days)
  for (let day = 1; day <= currentDay; day++) {
    const dateObj = new Date(year, month, day);
    const dayOfWeek = dateObj.getDay();
    if (dayOfWeek === 0) continue; // Only Sunday is holiday. Saturday is a working school day!

    const dateStr = dateObj.toISOString().split('T')[0];

    students.forEach((student) => {
      // Deterministic realistic probability
      const hash = (student.name.charCodeAt(0) * 17 + day * 31 + student.roll_number.charCodeAt(0)) % 100;
      let status: 'present' | 'absent' | 'late' | 'leave' = 'present';
      let remarks = '';

      if (dayOfWeek === 6) {
        // Saturday: students are present
        if (hash > 95) {
          status = 'absent';
          remarks = 'Absent on Saturday';
        } else if (hash > 90) {
          status = 'late';
          remarks = 'Late on Saturday';
        } else {
          status = 'present';
          remarks = 'Saturday class present';
        }
      } else if (hash > 92) {
        status = 'absent';
        remarks = 'Unexcused absence';
      } else if (hash > 86) {
        status = 'late';
        remarks = 'Arrived 15m late - transport delay';
      } else if (hash > 82) {
        status = 'leave';
        remarks = 'Sanctioned leave';
      }

      records.push({
        id: `att-${student.id}-${dateStr}`,
        student_id: student.id,
        date: dateStr,
        status,
        remarks: remarks || undefined,
        marked_by_teacher_id: 't-101',
        marked_by_teacher_name: 'Omorjit Singha',
        updated_at: dateObj.toISOString(),
      });
    });
  }

  return records;
}
