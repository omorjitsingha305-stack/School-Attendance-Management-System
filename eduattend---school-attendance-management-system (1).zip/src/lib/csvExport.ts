import { Student, AttendanceRecord, MonthlyStudentSummary } from '../types';

function downloadCsvFile(csvContent: string, fileName: string) {
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', fileName);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

function escapeCsvField(field: string | number | undefined | null): string {
  if (field === null || field === undefined) return '""';
  const str = String(field);
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return `"${str}"`;
}

// 1. Export Daily Roll Call
export function exportDailyAttendanceCsv(
  students: Student[],
  attendanceMap: Map<string, AttendanceRecord>,
  dateStr: string,
  grade: string,
  section: string
) {
  const headers = [
    'Roll Number',
    'Student Name',
    'Grade',
    'Section',
    'Date',
    'Attendance Status',
    'Remarks / Notes',
    'Marked By Teacher',
    'Guardian Contact',
  ];

  const rows = students.map((student) => {
    const dateObj = new Date(`${dateStr}T12:00:00`);
    const isSunday = dateObj.getDay() === 0;

    const record = attendanceMap.get(student.id);
    const status = isSunday
      ? 'HOLIDAY (SUNDAY)'
      : record?.status
      ? record.status.toUpperCase()
      : 'NOT MARKED';
    const remarks = isSunday
      ? 'Weekly Holiday - School Closed'
      : record?.remarks || '';
    const markedBy = isSunday ? 'School Calendar' : record?.marked_by_teacher_name || 'Staff';

    return [
      escapeCsvField(student.roll_number),
      escapeCsvField(student.name),
      escapeCsvField(student.grade),
      escapeCsvField(student.section),
      escapeCsvField(dateStr),
      escapeCsvField(status),
      escapeCsvField(remarks),
      escapeCsvField(markedBy),
      escapeCsvField(student.guardian_phone),
    ].join(',');
  });

  const csv = [headers.join(','), ...rows].join('\n');
  const safeClass = `${grade}_${section}`.replace(/\s+/g, '_');
  downloadCsvFile(csv, `KV_Masimpur_Attendance_${safeClass}_${dateStr}.csv`);
}

// 2. Export Monthly Attendance Matrix
export function exportMonthlyAttendanceCsv(
  monthlySummaries: MonthlyStudentSummary[],
  year: number,
  monthName: string,
  daysInMonth: number,
  grade: string,
  section: string
) {
  const dayHeaders = Array.from({ length: daysInMonth }, (_, i) => `Day ${i + 1}`);
  const headers = [
    'Roll Number',
    'Student Name',
    'Grade',
    'Section',
    ...dayHeaders,
    'Total Present',
    'Total Absent',
    'Total Late',
    'Total Leave',
    'Total Working Days',
    'Attendance %',
  ];

  const rows = monthlySummaries.map((summary) => {
    const dailyCells = Array.from({ length: daysInMonth }, (_, i) => {
      const day = i + 1;
      const status = summary.dailyStatus[day];
      if (!status) return escapeCsvField('-');
      if (status === 'present') return escapeCsvField('P');
      if (status === 'absent') return escapeCsvField('A');
      if (status === 'late') return escapeCsvField('L');
      if (status === 'leave') return escapeCsvField('Lv');
      return escapeCsvField('-');
    });

    return [
      escapeCsvField(summary.student.roll_number),
      escapeCsvField(summary.student.name),
      escapeCsvField(summary.student.grade),
      escapeCsvField(summary.student.section),
      ...dailyCells,
      escapeCsvField(summary.totalPresent),
      escapeCsvField(summary.totalAbsent),
      escapeCsvField(summary.totalLate),
      escapeCsvField(summary.totalLeave),
      escapeCsvField(summary.workingDays),
      escapeCsvField(`${summary.attendancePercentage}%`),
    ].join(',');
  });

  const csv = [headers.join(','), ...rows].join('\n');
  const safeClass = `${grade}_${section}`.replace(/\s+/g, '_');
  downloadCsvFile(csv, `KV_Masimpur_Monthly_Attendance_${safeClass}_${monthName}_${year}.csv`);
}

// 3. Export Student Directory
export function exportStudentRosterCsv(students: Student[]) {
  const headers = [
    'Roll Number',
    'Full Name',
    'Grade',
    'Section',
    'Gender',
    'Guardian Name',
    'Guardian Phone',
    'Student Email',
    'Admission Date',
  ];

  const rows = students.map((s) =>
    [
      escapeCsvField(s.roll_number),
      escapeCsvField(s.name),
      escapeCsvField(s.grade),
      escapeCsvField(s.section),
      escapeCsvField(s.gender),
      escapeCsvField(s.guardian_name),
      escapeCsvField(s.guardian_phone),
      escapeCsvField(s.email || ''),
      escapeCsvField(s.admission_date || ''),
    ].join(',')
  );

  const csv = [headers.join(','), ...rows].join('\n');
  downloadCsvFile(csv, `KV_Masimpur_Students_Roster_${new Date().toISOString().split('T')[0]}.csv`);
}
