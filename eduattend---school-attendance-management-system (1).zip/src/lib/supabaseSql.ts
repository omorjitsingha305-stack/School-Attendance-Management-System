export const SUPABASE_SETUP_SQL = `-- ========================================================
-- SCHOOL ATTENDANCE SYSTEM - SUPABASE DATABASE SCHEMA
-- Run this in your Supabase Project -> SQL Editor -> Run
-- ========================================================

-- 1. Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. Create Teachers Profiles Table
CREATE TABLE IF NOT EXISTS public.teachers (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'Class Teacher',
    assigned_class TEXT DEFAULT 'Class 10',
    assigned_section TEXT DEFAULT 'A',
    school_name TEXT DEFAULT 'PM Shri Kendriya Vidyalaya Masimpur',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Create Students Table
CREATE TABLE IF NOT EXISTS public.students (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    roll_number TEXT NOT NULL,
    name TEXT NOT NULL,
    grade TEXT NOT NULL,
    section TEXT NOT NULL,
    gender TEXT CHECK (gender IN ('Male', 'Female', 'Other')),
    guardian_name TEXT,
    guardian_phone TEXT,
    email TEXT,
    admission_date DATE DEFAULT CURRENT_DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(grade, section, roll_number)
);

-- 4. Create Attendance Table
CREATE TABLE IF NOT EXISTS public.attendance (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('present', 'absent', 'late', 'leave')),
    remarks TEXT,
    marked_by_teacher_id UUID REFERENCES public.teachers(id) ON DELETE SET NULL,
    marked_by_teacher_name TEXT,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(student_id, date)
);

-- 5. Indexes for fast query performance
CREATE INDEX IF NOT EXISTS idx_students_class_sec ON public.students(grade, section);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON public.attendance(date);
CREATE INDEX IF NOT EXISTS idx_attendance_student_date ON public.attendance(student_id, date);

-- 6. Enable Row Level Security (RLS)
ALTER TABLE public.teachers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance ENABLE ROW LEVEL SECURITY;

-- 7. Security Policies (Teachers can view and manage all student attendance records)
-- Teachers Table Policies
CREATE POLICY "Allow authenticated teachers to read all teacher profiles"
    ON public.teachers FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "Allow authenticated users to insert/update their own profile"
    ON public.teachers FOR ALL
    TO authenticated
    USING (auth.uid() = id);

-- Students Table Policies
CREATE POLICY "Allow authenticated teachers to read all students"
    ON public.students FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "Allow authenticated teachers to insert students"
    ON public.students FOR INSERT
    TO authenticated
    WITH CHECK (true);

CREATE POLICY "Allow authenticated teachers to update students"
    ON public.students FOR UPDATE
    TO authenticated
    USING (true);

CREATE POLICY "Allow authenticated teachers to delete students"
    ON public.students FOR DELETE
    TO authenticated
    USING (true);

-- Attendance Table Policies
CREATE POLICY "Allow authenticated teachers to view attendance"
    ON public.attendance FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "Allow authenticated teachers to insert attendance"
    ON public.attendance FOR INSERT
    TO authenticated
    WITH CHECK (true);

CREATE POLICY "Allow authenticated teachers to update attendance"
    ON public.attendance FOR UPDATE
    TO authenticated
    USING (true);

-- 8. Seed Initial Sample Students (Class 1 to 12 & 11/12 Science, Commerce, Humanities)
INSERT INTO public.students (roll_number, name, grade, section, gender, guardian_name, guardian_phone)
VALUES
    ('101', 'Leo Anderson', 'Class 1', 'A', 'Male', 'Arthur Anderson', '+1 (555) 111-2201'),
    ('102', 'Aria Sharma', 'Class 1', 'A', 'Female', 'Pooja Sharma', '+1 (555) 111-2202'),
    ('101', 'Oliver Twist', 'Class 2', 'A', 'Male', 'Rose Brown', '+1 (555) 111-2203'),
    ('101', 'Mason Davis', 'Class 3', 'A', 'Male', 'William Davis', '+1 (555) 111-2205'),
    ('101', 'Ella Scott', 'Class 4', 'A', 'Female', 'Clara Scott', '+1 (555) 111-2206'),
    ('101', 'Lucas Green', 'Class 5', 'A', 'Male', 'Richard Green', '+1 (555) 111-2207'),
    ('101', 'Hannah Abbott', 'Class 6', 'A', 'Female', 'Philip Abbott', '+1 (555) 111-2208'),
    ('101', 'Jack Wilson', 'Class 7', 'A', 'Male', 'Daniel Wilson', '+1 (555) 111-2209'),
    ('101', 'Grace Miller', 'Class 8', 'A', 'Female', 'Alan Miller', '+1 (555) 111-2210'),
    ('301', 'Benjamin Hayes', 'Class 9', 'A', 'Male', 'George Hayes', '+1 (555) 556-6778'),
    ('302', 'Harper Bailey', 'Class 9', 'A', 'Female', 'Laura Bailey', '+1 (555) 667-7889'),
    ('101', 'Alexander Reed', 'Class 10', 'A', 'Male', 'Marcus Reed', '+1 (555) 234-5678'),
    ('102', 'Sophia Chen', 'Class 10', 'A', 'Female', 'Wei Chen', '+1 (555) 345-6789'),
    ('103', 'Liam Vance', 'Class 10', 'A', 'Male', 'Sarah Vance', '+1 (555) 456-7890'),
    ('104', 'Emily Watson', 'Class 10', 'A', 'Female', 'David Watson', '+1 (555) 567-8901'),
    ('201', 'Lucas Garcia', 'Class 10', 'B', 'Male', 'Carlos Garcia', '+1 (555) 112-2334'),
    -- Class 11 Streams
    ('1101', 'Daniel Cooper', 'Class 11', 'Science', 'Male', 'Simon Cooper', '+1 (555) 889-9001'),
    ('1102', 'Ella Howard', 'Class 11', 'Science', 'Female', 'Judith Howard', '+1 (555) 990-0112'),
    ('1121', 'Ananya Roy', 'Class 11', 'Commerce', 'Female', 'Subhash Roy', '+1 (555) 991-0201'),
    ('1122', 'Marcus Brody', 'Class 11', 'Commerce', 'Male', 'Frank Brody', '+1 (555) 991-0202'),
    ('1141', 'Maya Angelis', 'Class 11', 'Humanities', 'Female', 'Nicholas Angelis', '+1 (555) 992-0301'),
    ('1142', 'Gabriel Morales', 'Class 11', 'Humanities', 'Male', 'Maria Morales', '+1 (555) 992-0302'),
    -- Class 12 Streams
    ('1201', 'Aditya Sen', 'Class 12', 'Science', 'Male', 'Pradeep Sen', '+1 (555) 993-0401'),
    ('1202', 'Serena Gomez', 'Class 12', 'Science', 'Female', 'Lucia Gomez', '+1 (555) 993-0402'),
    ('1221', 'William Torres', 'Class 12', 'Commerce', 'Male', 'Victor Torres', '+1 (555) 123-9876'),
    ('1222', 'Priya Narang', 'Class 12', 'Commerce', 'Female', 'Harish Narang', '+1 (555) 123-9877'),
    ('1241', 'Julian Thorne', 'Class 12', 'Humanities', 'Male', 'Julian Thorne Sr.', '+1 (555) 994-0501'),
    ('1242', 'Zara Al-Mansoor', 'Class 12', 'Humanities', 'Female', 'Tariq Al-Mansoor', '+1 (555) 994-0502')
ON CONFLICT (grade, section, roll_number) DO NOTHING;
`;
