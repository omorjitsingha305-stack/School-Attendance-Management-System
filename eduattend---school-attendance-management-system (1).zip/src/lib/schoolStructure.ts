export const ALL_CLASSES = [
  'Class 1',
  'Class 2',
  'Class 3',
  'Class 4',
  'Class 5',
  'Class 6',
  'Class 7',
  'Class 8',
  'Class 9',
  'Class 10',
  'Class 11',
  'Class 12',
] as const;

export const SENIOR_CLASSES = ['Class 11', 'Class 12'] as const;

export const SENIOR_STREAMS = ['Science', 'Commerce', 'Humanities'] as const;

export const JUNIOR_SECTIONS = ['A', 'B'] as const;

export function isSeniorClass(className: string): boolean {
  return className === 'Class 11' || className === 'Class 12' || className === 'Grade 11' || className === 'Grade 12';
}

export function getAvailableSectionsOrStreams(className: string): string[] {
  if (isSeniorClass(className)) {
    return ['Science', 'Commerce', 'Humanities'];
  }
  return ['A', 'B'];
}

export function normalizeClassName(className: string): string {
  // Normalize "Grade X" to "Class X" if needed, while keeping compatibility
  if (className.startsWith('Grade ')) {
    return className.replace('Grade ', 'Class ');
  }
  return className;
}
