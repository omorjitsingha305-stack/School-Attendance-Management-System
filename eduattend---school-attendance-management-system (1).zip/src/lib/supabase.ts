import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { SupabaseConfig } from '../types';

const STORAGE_KEY = 'eduattend_supabase_config';

// Read default env if available
const envUrl = import.meta.env.VITE_SUPABASE_URL || '';
const envKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export function getSavedConfig(): SupabaseConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed.url && parsed.anonKey) {
        return {
          url: parsed.url,
          anonKey: parsed.anonKey,
          isCustom: true,
          isValidated: !!parsed.isValidated,
        };
      }
    }
  } catch (e) {
    console.error('Error reading saved Supabase config:', e);
  }

  return {
    url: envUrl,
    anonKey: envKey,
    isCustom: false,
    isValidated: false,
  };
}

let activeClient: SupabaseClient | null = null;
let currentConfigSignature = '';

export function getSupabaseClient(): SupabaseClient | null {
  const config = getSavedConfig();
  if (!config.url || !config.anonKey) {
    return null;
  }

  const sig = `${config.url}::${config.anonKey}`;
  if (!activeClient || currentConfigSignature !== sig) {
    try {
      activeClient = createClient(config.url, config.anonKey, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
        },
      });
      currentConfigSignature = sig;
    } catch (err) {
      console.error('Failed to create Supabase client:', err);
      return null;
    }
  }

  return activeClient;
}

export async function testSupabaseConnection(
  url: string,
  anonKey: string
): Promise<{ success: boolean; message: string }> {
  try {
    if (!url.startsWith('https://')) {
      return { success: false, message: 'URL must start with https://' };
    }
    const testClient = createClient(url, anonKey);
    // Try pinging students table or get session
    const { error } = await testClient.from('students').select('count').limit(1);

    if (error) {
      // If table doesn't exist yet, but credentials worked
      if (error.code === '42P01' || error.message.includes('relation "public.students" does not exist')) {
        return {
          success: true,
          message: 'Connected to Supabase! (Note: Remember to run the SQL schema to create tables)',
        };
      }
      return {
        success: false,
        message: error.message || 'Supabase connection rejected. Verify your Project URL & Anon Key.',
      };
    }

    return {
      success: true,
      message: 'Successfully connected and verified Supabase database!',
    };
  } catch (err: any) {
    return {
      success: false,
      message: err?.message || 'Network error connecting to Supabase instance.',
    };
  }
}

export function saveSupabaseConfig(url: string, anonKey: string, isValidated = true): void {
  localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify({
      url: url.trim(),
      anonKey: anonKey.trim(),
      isValidated,
    })
  );
  activeClient = null;
  currentConfigSignature = '';
}

export function resetSupabaseConfig(): void {
  localStorage.removeItem(STORAGE_KEY);
  activeClient = null;
  currentConfigSignature = '';
}
