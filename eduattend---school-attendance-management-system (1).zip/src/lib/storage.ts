import { Student, AttendanceRecord, TeacherUser, AttendanceStatus } from '../types';
import { INITIAL_STUDENTS, INITIAL_TEACHERS, generateInitialAttendance } from './sampleData';
import { getSupabaseClient } from './supabase';

const STUDENTS_KEY = 'eduattend_students_v2';
const ATTENDANCE_KEY = 'eduattend_attendance_v3';
const TEACHERS_KEY = 'eduattend_teachers_v2';
const CURRENT_TEACHER_KEY = 'eduattend_current_teacher_v2';

// BroadcastChannel for instant live synchronization across multiple tabs/windows
const syncChannel = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('eduattend_school_sync') : null;

// Listeners for sync events
const changeListeners: Set<() => void> = new Set();

if (syncChannel) {
  syncChannel.onmessage = (event) => {
    if (event.data?.type === 'DATA_UPDATED') {
      changeListeners.forEach((listener) => listener());
    }
  };
}

export function subscribeToDataChanges(callback: () => void): () => void {
  changeListeners.add(callback);
  return () => {
    changeListeners.delete(callback);
  };
}

function notifyDataChanged() {
  changeListeners.forEach((listener) => listener());
  if (syncChannel) {
    try {
      syncChannel.postMessage({ type: 'DATA_UPDATED', timestamp: Date.now() });
    } catch (e) {
      // Ignore broadcast errors
    }
  }
}

// ----------------------------------------------------------------------
// Local Storage Initialization
// ----------------------------------------------------------------------
function getLocalStudents(): Student[] {
  try {
    const raw = localStorage.getItem(STUDENTS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse students:', e);
  }
  const initial = INITIAL_STUDENTS;
  localStorage.setItem(STUDENTS_KEY, JSON.stringify(initial));
  return initial;
}

function getLocalAttendance(): AttendanceRecord[] {
  try {
    const raw = localStorage.getItem(ATTENDANCE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse attendance:', e);
  }
  const students = getLocalStudents();
  const initial = generateInitialAttendance(students);
  localStorage.setItem(ATTENDANCE_KEY, JSON.stringify(initial));
  return initial;
}

function getLocalTeachers(): TeacherUser[] {
  try {
    const raw = localStorage.getItem(TEACHERS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse teachers:', e);
  }
  const initial = INITIAL_TEACHERS;
  localStorage.setItem(TEACHERS_KEY, JSON.stringify(initial));
  return initial;
}

// ----------------------------------------------------------------------
// Teacher & Auth Operations
// ----------------------------------------------------------------------
export function getCurrentTeacher(): TeacherUser | null {
  try {
    const raw = localStorage.getItem(CURRENT_TEACHER_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse current teacher:', e);
  }
  // Default to Sarah Jenkins so teachers can try out immediately
  const defaultTeacher = INITIAL_TEACHERS[0];
  setCurrentTeacher(defaultTeacher);
  return defaultTeacher;
}

export function setCurrentTeacher(teacher: TeacherUser | null): void {
  if (teacher) {
    localStorage.setItem(CURRENT_TEACHER_KEY, JSON.stringify(teacher));
  } else {
    localStorage.removeItem(CURRENT_TEACHER_KEY);
  }
  notifyDataChanged();
}

export async function loginTeacher(
  email: string,
  pass: string
): Promise<{ success: boolean; teacher?: TeacherUser; error?: string }> {
  const supabase = getSupabaseClient();
  const normalizedEmail = email.trim().toLowerCase();

  if (supabase) {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: normalizedEmail,
        password: pass,
      });

      if (error) {
        return { success: false, error: error.message };
      }

      if (data?.user) {
        // Fetch or create profile in teachers table
        const { data: profile } = await supabase
          .from('teachers')
          .select('*')
          .eq('id', data.user.id)
          .single();

        const teacherUser: TeacherUser = {
          id: data.user.id,
          email: data.user.email || normalizedEmail,
          name: profile?.name || data.user.user_metadata?.name || normalizedEmail.split('@')[0],
          role: profile?.role || 'Class Teacher',
          assigned_class: profile?.assigned_class || 'Grade 10',
          assigned_section: profile?.assigned_section || 'A',
          school_name: profile?.school_name || 'PM Shri Kendriya Vidyalaya Masimpur',
        };

        setCurrentTeacher(teacherUser);
        return { success: true, teacher: teacherUser };
      }
    } catch (e: any) {
      console.warn('Supabase auth failed, falling back to local verification:', e);
    }
  }

  // Local / Shared fallback
  const teachers = getLocalTeachers();
  let found = teachers.find((t) => t.email.toLowerCase() === normalizedEmail);

  if (!found) {
    // Check if valid email pattern, auto-register
    if (normalizedEmail.includes('@')) {
      const newTeacher: TeacherUser = {
        id: `t-${Date.now()}`,
        email: normalizedEmail,
        name: normalizedEmail.split('@')[0].replace('.', ' '),
        role: 'Class Teacher',
        assigned_class: 'Grade 10',
        assigned_section: 'A',
        school_name: 'PM Shri Kendriya Vidyalaya Masimpur',
      };
      teachers.push(newTeacher);
      localStorage.setItem(TEACHERS_KEY, JSON.stringify(teachers));
      found = newTeacher;
    } else {
      return { success: false, error: 'Teacher account not found. Please provide a valid email.' };
    }
  }

  setCurrentTeacher(found);
  return { success: true, teacher: found };
}

export async function registerTeacher(
  email: string,
  pass: string,
  name: string,
  assignedClass: string,
  assignedSection: string
): Promise<{ success: boolean; teacher?: TeacherUser; error?: string }> {
  const supabase = getSupabaseClient();
  const normalizedEmail = email.trim().toLowerCase();

  if (supabase) {
    try {
      const { data, error } = await supabase.auth.signUp({
        email: normalizedEmail,
        password: pass,
        options: {
          data: {
            name,
            assigned_class: assignedClass,
            assigned_section: assignedSection,
          },
        },
      });

      if (error) {
        return { success: false, error: error.message };
      }

      if (data?.user) {
        const teacherUser: TeacherUser = {
          id: data.user.id,
          email: normalizedEmail,
          name,
          role: 'Class Teacher',
          assigned_class: assignedClass,
          assigned_section: assignedSection,
          school_name: 'PM Shri Kendriya Vidyalaya Masimpur',
        };

        // Try upserting to teachers table
        await supabase.from('teachers').upsert({
          id: data.user.id,
          email: normalizedEmail,
          name,
          role: 'Class Teacher',
          assigned_class: assignedClass,
          assigned_section: assignedSection,
          school_name: 'PM Shri Kendriya Vidyalaya Masimpur',
        });

        setCurrentTeacher(teacherUser);
        return { success: true, teacher: teacherUser };
      }
    } catch (e: any) {
      console.warn('Supabase sign up error, registering locally:', e);
    }
  }

  // Local storage registration
  const teachers = getLocalTeachers();
  const existing = teachers.find((t) => t.email.toLowerCase() === normalizedEmail);
  if (existing) {
    return { success: false, error: 'An account with this email already exists.' };
  }

  const newTeacher: TeacherUser = {
    id: `t-${Date.now()}`,
    email: normalizedEmail,
    name,
    role: 'Class Teacher',
    assigned_class: assignedClass,
    assigned_section: assignedSection,
    school_name: 'PM Shri Kendriya Vidyalaya Masimpur',
  };

  teachers.push(newTeacher);
  localStorage.setItem(TEACHERS_KEY, JSON.stringify(teachers));
  setCurrentTeacher(newTeacher);
  return { success: true, teacher: newTeacher };
}

export async function logoutTeacher(): Promise<void> {
  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.auth.signOut();
    } catch (e) {
      // Ignore
    }
  }
  setCurrentTeacher(null);
}

export function getAllTeachers(): TeacherUser[] {
  return getLocalTeachers();
}

export async function updateTeacherProfile(
  teacherId: string,
  updatedData: Partial<TeacherUser>
): Promise<TeacherUser> {
  const teachers = getLocalTeachers();
  const index = teachers.findIndex((t) => t.id === teacherId);

  let updated: TeacherUser;
  if (index >= 0) {
    updated = { ...teachers[index], ...updatedData };
    teachers[index] = updated;
  } else {
    const cur = getCurrentTeacher();
    updated = { ...(cur || INITIAL_TEACHERS[0]), ...updatedData, id: teacherId };
    teachers.push(updated);
  }

  localStorage.setItem(TEACHERS_KEY, JSON.stringify(teachers));

  const cur = getCurrentTeacher();
  if (cur?.id === teacherId || !cur) {
    setCurrentTeacher(updated);
  }

  // Also sync to Supabase if connected
  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.from('teachers').upsert({
        id: updated.id,
        name: updated.name,
        role: updated.role,
        assigned_class: updated.assigned_class,
        assigned_section: updated.assigned_section,
        school_name: updated.school_name,
        email: updated.email,
      });
    } catch (e) {
      console.warn('Supabase updateTeacherProfile failed, updated locally:', e);
    }
  }

  notifyDataChanged();
  return updated;
}

export async function addTeacher(
  teacherData: Omit<TeacherUser, 'id'>
): Promise<TeacherUser> {
  const teachers = getLocalTeachers();
  const newTeacher: TeacherUser = {
    ...teacherData,
    id: `t-${Date.now()}`,
  };

  teachers.push(newTeacher);
  localStorage.setItem(TEACHERS_KEY, JSON.stringify(teachers));

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.from('teachers').insert({
        id: newTeacher.id,
        name: newTeacher.name,
        email: newTeacher.email,
        role: newTeacher.role,
        assigned_class: newTeacher.assigned_class,
        assigned_section: newTeacher.assigned_section,
        school_name: newTeacher.school_name,
      });
    } catch (e) {
      console.warn('Supabase addTeacher failed, added locally:', e);
    }
  }

  notifyDataChanged();
  return newTeacher;
}

export async function deleteTeacher(teacherId: string): Promise<boolean> {
  const teachers = getLocalTeachers();
  if (teachers.length <= 1) {
    return false; // Preserve at least one teacher
  }

  const filtered = teachers.filter((t) => t.id !== teacherId);
  localStorage.setItem(TEACHERS_KEY, JSON.stringify(filtered));

  const cur = getCurrentTeacher();
  if (cur?.id === teacherId) {
    setCurrentTeacher(filtered[0] || null);
  }

  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      await supabase.from('teachers').delete().eq('id', teacherId);
    } catch (e) {
      console.warn('Supabase deleteTeacher failed:', e);
    }
  }

  notifyDataChanged();
  return true;
}

export function switchTeacher(teacherId: string): TeacherUser | null {
  const teachers = getLocalTeachers();
  const target = teachers.find((t) => t.id === teacherId);
  if (target) {
    setCurrentTeacher(target);
    notifyDataChanged();
    return target;
  }
  return null;
}

// ----------------------------------------------------------------------
// Students Operations (Add, Edit, Delete, Fetch)
// ----------------------------------------------------------------------
export async function getStudents(): Promise<Student[]> {
  const supabase = getSupabaseClient();
  if (supabase) {
    try {
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .order('grade', { ascending: true })
        .order('section', { ascending: true })
        .order('roll_number', { ascending: true });

      if (!error && data && data.length > 0) {
        return data as Student[];
      }
    } catch (e) {
      console.warn('Supabase getStudents error, falling back to local storage:', e);
    }
  }

  return getLocalStudents();
}

export async function saveStudent(studentData: Omit<Student, 'id' | 'created_at'> & { id?: string }): Promise<Student> {
  const supabase = getSupabaseClient();
  const isEditing = !!studentData.id;

  const student: Student = {
    ...studentData,
    id: studentData.id || `s-${Date.now()}`,
    created_at: new Date().toISOString(),
  };

  if (supabase) {
    try {
      if (isEditing) {
        const { data, error } = await supabase
          .from('students')
          .update({
            name: student.name,
            roll_number: student.roll_number,
            grade: student.grade,
            section: student.section,
            gender: student.gender,
            guardian_name: student.guardian_name,
            guardian_phone: student.guardian_phone,
            email: student.email,
          })
          .eq('id', student.id)
          .select()
          .single();

        if (!error && data) {
          notifyDataChanged();
          return data as Student;
        }
      } else {
        const { data, error } = await supabase
          .from('students')
          .insert({
            name: student.name,
            roll_number: student.roll_number,
            grade: student.grade,
            section: student.section,
            gender: student.gender,
            guardian_name: student.guardian_name,
            guardian_phone: student.guardian_phone,
            email: student.email,
          })
          .select()
          .single();

        if (!error && data) {
          notifyDataChanged();
          return data as Student;
        }
      }
    } catch (e) {
      console.warn('Supabase saveStudent failed, saving locally:', e);
    }
  }

  // Local storage save
  const current = getLocalStudents();
  let updated: Student[];
  if (isEditing) {
    updated = current.map((s) => (s.id === student.id ? { ...s, ...student } : s));
  } else {
    updated = [...current, student];
  }

  localStorage.setItem(STUDENTS_KEY, JSON.stringify(updated));
  notifyDataChanged();
  return student;
}

export async function deleteStudent(studentId: string): Promise<boolean> {
  const supabase = getSupabaseClient();

  if (supabase) {
    try {
      const { error } = await supabase.from('students').delete().eq('id', studentId);
      if (!error) {
        notifyDataChanged();
        return true;
      }
    } catch (e) {
      console.warn('Supabase deleteStudent failed, falling back to local:', e);
    }
  }

  const current = getLocalStudents();
  const filtered = current.filter((s) => s.id !== studentId);
  localStorage.setItem(STUDENTS_KEY, JSON.stringify(filtered));

  // Also clean up student's attendance records
  const attCurrent = getLocalAttendance();
  const attFiltered = attCurrent.filter((a) => a.student_id !== studentId);
  localStorage.setItem(ATTENDANCE_KEY, JSON.stringify(attFiltered));

  notifyDataChanged();
  return true;
}

// ----------------------------------------------------------------------
// Attendance Operations (Daily Roll Call, Batch Marking, Monthly)
// ----------------------------------------------------------------------
export async function getAttendanceByDate(dateStr: string): Promise<AttendanceRecord[]> {
  const supabase = getSupabaseClient();

  if (supabase) {
    try {
      const { data, error } = await supabase
        .from('attendance')
        .select('*')
        .eq('date', dateStr);

      if (!error && data) {
        return data as AttendanceRecord[];
      }
    } catch (e) {
      console.warn('Supabase getAttendanceByDate failed, falling back to local:', e);
    }
  }

  const all = getLocalAttendance();
  return all.filter((r) => r.date === dateStr);
}

export async function getAttendanceForMonth(year: number, monthIndex: number): Promise<AttendanceRecord[]> {
  const supabase = getSupabaseClient();
  const startDay = `${year}-${String(monthIndex + 1).padStart(2, '0')}-01`;
  const lastDayOfMonth = new Date(year, monthIndex + 1, 0).getDate();
  const endDay = `${year}-${String(monthIndex + 1).padStart(2, '0')}-${String(lastDayOfMonth).padStart(2, '0')}`;

  if (supabase) {
    try {
      const { data, error } = await supabase
        .from('attendance')
        .select('*')
        .gte('date', startDay)
        .lte('date', endDay);

      if (!error && data) {
        return data as AttendanceRecord[];
      }
    } catch (e) {
      console.warn('Supabase getAttendanceForMonth failed, falling back to local:', e);
    }
  }

  const all = getLocalAttendance();
  return all.filter((r) => r.date >= startDay && r.date <= endDay);
}

export async function saveAttendanceRecord(
  studentId: string,
  dateStr: string,
  status: AttendanceStatus,
  remarks?: string
): Promise<AttendanceRecord> {
  const currentTeacher = getCurrentTeacher();
  const supabase = getSupabaseClient();

  const record: AttendanceRecord = {
    id: `att-${studentId}-${dateStr}`,
    student_id: studentId,
    date: dateStr,
    status,
    remarks: remarks || undefined,
    marked_by_teacher_id: currentTeacher?.id,
    marked_by_teacher_name: currentTeacher?.name,
    updated_at: new Date().toISOString(),
  };

  if (supabase) {
    try {
      const { data, error } = await supabase
        .from('attendance')
        .upsert(
          {
            student_id: studentId,
            date: dateStr,
            status,
            remarks: remarks || null,
            marked_by_teacher_id: currentTeacher?.id,
            marked_by_teacher_name: currentTeacher?.name,
            updated_at: new Date().toISOString(),
          },
          { onConflict: 'student_id,date' }
        )
        .select()
        .single();

      if (!error && data) {
        notifyDataChanged();
        return data as AttendanceRecord;
      }
    } catch (e) {
      console.warn('Supabase saveAttendance failed, saving locally:', e);
    }
  }

  // Local storage save
  const all = getLocalAttendance();
  const idx = all.findIndex((r) => r.student_id === studentId && r.date === dateStr);
  if (idx >= 0) {
    all[idx] = record;
  } else {
    all.push(record);
  }

  localStorage.setItem(ATTENDANCE_KEY, JSON.stringify(all));
  notifyDataChanged();
  return record;
}

export async function batchSaveAttendance(
  records: Array<{ studentId: string; status: AttendanceStatus; remarks?: string }>,
  dateStr: string
): Promise<void> {
  const currentTeacher = getCurrentTeacher();
  const supabase = getSupabaseClient();
  const now = new Date().toISOString();

  if (supabase) {
    try {
      const payload = records.map((r) => ({
        student_id: r.studentId,
        date: dateStr,
        status: r.status,
        remarks: r.remarks || null,
        marked_by_teacher_id: currentTeacher?.id,
        marked_by_teacher_name: currentTeacher?.name,
        updated_at: now,
      }));

      const { error } = await supabase.from('attendance').upsert(payload, { onConflict: 'student_id,date' });
      if (!error) {
        notifyDataChanged();
        return;
      }
    } catch (e) {
      console.warn('Supabase batchSaveAttendance failed, saving locally:', e);
    }
  }

  // Local storage
  const all = getLocalAttendance();
  records.forEach((r) => {
    const idx = all.findIndex((item) => item.student_id === r.studentId && item.date === dateStr);
    const rec: AttendanceRecord = {
      id: `att-${r.studentId}-${dateStr}`,
      student_id: r.studentId,
      date: dateStr,
      status: r.status,
      remarks: r.remarks || undefined,
      marked_by_teacher_id: currentTeacher?.id,
      marked_by_teacher_name: currentTeacher?.name,
      updated_at: now,
    };
    if (idx >= 0) {
      all[idx] = rec;
    } else {
      all.push(rec);
    }
  });

  localStorage.setItem(ATTENDANCE_KEY, JSON.stringify(all));
  notifyDataChanged();
}

export function resetToSampleData(): void {
  localStorage.setItem(STUDENTS_KEY, JSON.stringify(INITIAL_STUDENTS));
  const att = generateInitialAttendance(INITIAL_STUDENTS);
  localStorage.setItem(ATTENDANCE_KEY, JSON.stringify(att));
  localStorage.setItem(TEACHERS_KEY, JSON.stringify(INITIAL_TEACHERS));
  setCurrentTeacher(INITIAL_TEACHERS[0]);
  notifyDataChanged();
}
