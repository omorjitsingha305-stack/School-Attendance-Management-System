export type AttendanceStatus = 'present' | 'absent' | 'late' | 'leave';

export interface Student {
  id: string;
  roll_number: string;
  name: string;
  grade: string; // e.g. "Grade 9", "Grade 10", "Grade 11", "Grade 12"
  section: string; // e.g. "A", "B", "C"
  gender: 'Male' | 'Female' | 'Other';
  guardian_name: string;
  guardian_phone: string;
  email?: string;
  admission_date?: string;
  created_at: string;
}

export interface AttendanceRecord {
  id: string;
  student_id: string;
  date: string; // YYYY-MM-DD
  status: AttendanceStatus;
  remarks?: string;
  marked_by_teacher_id?: string;
  marked_by_teacher_name?: string;
  updated_at: string;
}

export interface TeacherUser {
  id: string;
  email: string;
  name: string;
  role: 'Class Teacher' | 'Subject Teacher' | 'Head of Department' | 'Principal';
  assigned_class: string;
  assigned_section: string;
  school_name: string;
}

export interface ClassStats {
  total: number;
  present: number;
  absent: number;
  late: number;
  leave: number;
  rate: number;
}

export interface MonthlyStudentSummary {
  student: Student;
  dailyStatus: Record<number, AttendanceStatus | null>; // day (1..31) -> status
  totalPresent: number;
  totalAbsent: number;
  totalLate: number;
  totalLeave: number;
  workingDays: number;
  attendancePercentage: number;
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  isCustom: boolean;
  isValidated: boolean;
}
