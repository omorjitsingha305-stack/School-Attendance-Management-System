import React, { useState, useEffect, useCallback } from 'react';
import {
  Calendar,
  Users,
  BarChart3,
  FileSpreadsheet,
  Database,
  CloudCheck,
  ShieldCheck,
  School,
  ExternalLink,
} from 'lucide-react';
import { Navbar } from './components/Navbar';
import { DailyAttendanceView } from './components/DailyAttendanceView';
import { MonthlyReportView } from './components/MonthlyReportView';
import { StudentDirectoryView } from './components/StudentDirectoryView';
import { AnalyticsView } from './components/AnalyticsView';
import { AuthModal } from './components/AuthModal';
import { TeacherProfileModal } from './components/TeacherProfileModal';
import { SupabaseSetupModal } from './components/SupabaseSetupModal';
import { StudentFormModal } from './components/StudentFormModal';
import {
  getStudents,
  saveStudent,
  deleteStudent,
  batchSaveAttendance,
  getCurrentTeacher,
  subscribeToDataChanges,
} from './lib/storage';
import { getLocalAttendanceRecords } from './lib/attendanceQuery';
import { getSavedConfig } from './lib/supabase';
import { Student, AttendanceRecord, TeacherUser, AttendanceStatus } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<'daily' | 'monthly' | 'students' | 'analytics'>('daily');
  const [students, setStudents] = useState<Student[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [currentTeacher, setCurrentTeacherState] = useState<TeacherUser | null>(getCurrentTeacher());
  const [loading, setLoading] = useState(true);

  // Modals
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isSupabaseSetupOpen, setIsSupabaseSetupOpen] = useState(false);
  const [isStudentFormOpen, setIsStudentFormOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  // Config
  const [supabaseConfig, setSupabaseConfig] = useState(getSavedConfig());

  // Data fetching
  const refreshData = useCallback(async () => {
    try {
      const studentList = await getStudents();
      setStudents(studentList);
      const records = getLocalAttendanceRecords();
      setAttendanceRecords(records);
    } catch (e) {
      console.error('Error refreshing school records:', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshData();
    // Subscribe to multi-tab broadcast sync
    const unsubscribe = subscribeToDataChanges(() => {
      refreshData();
      setCurrentTeacherState(getCurrentTeacher());
    });
    return () => unsubscribe();
  }, [refreshData]);

  // Handlers
  const handleSaveAttendance = async (
    records: Array<{ studentId: string; status: AttendanceStatus; remarks?: string }>,
    dateStr: string
  ) => {
    await batchSaveAttendance(records, dateStr);
    refreshData();
  };

  const handleSaveStudent = async (studentData: Omit<Student, 'id' | 'created_at'> & { id?: string }) => {
    await saveStudent(studentData);
    refreshData();
  };

  const handleDeleteStudent = async (studentId: string) => {
    await deleteStudent(studentId);
    refreshData();
  };

  const handleOpenEditStudent = (student: Student) => {
    setEditingStudent(student);
    setIsStudentFormOpen(true);
  };

  const handleOpenAddStudent = () => {
    setEditingStudent(null);
    setIsStudentFormOpen(true);
  };

  const isSupabaseConnected = Boolean(supabaseConfig.url && supabaseConfig.anonKey);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Top Bar following Top Bar Contract */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentTeacher={currentTeacher}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenDatabaseSetup={() => setIsSupabaseSetupOpen(true)}
        isSupabaseConnected={isSupabaseConnected}
      />

      {/* Cloud Status / Mode Banner */}
      <div className="bg-slate-900 text-slate-200 px-2 sm:px-4 md:px-6 py-2 text-xs border-b border-slate-800">
        <div className="w-full flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="inline-flex items-center gap-1.5 font-bold text-white tracking-wide">
              <School className="w-4 h-4 text-amber-400" />
              PM SHRI KENDRIYA VIDYALAYA MASIMPUR
            </span>
            <span className="text-slate-500" aria-hidden="true">·</span>
            <span className="text-slate-300">
              Teacher: <strong className="text-white">{currentTeacher?.name || 'Omorjit Singha'}</strong>
            </span>
          </div>

          <div className="flex items-center gap-3">
            {isSupabaseConnected ? (
              <span className="text-emerald-400 font-medium flex items-center gap-1.5 text-[11px]">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Supabase PostgreSQL Connected
              </span>
            ) : (
              <button
                onClick={() => setIsSupabaseSetupOpen(true)}
                className="text-indigo-300 hover:text-white font-medium flex items-center gap-1 text-[11px] underline underline-offset-2 transition-colors"
              >
                <Database className="w-3.5 h-3.5 text-indigo-400" />
                Connect Cloud Supabase Database &rarr;
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Container */}
      <main className="flex-1 w-full px-2 sm:px-4 md:px-6 lg:max-w-7xl lg:mx-auto py-4 sm:py-6">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 text-slate-500">
            <div className="w-8 h-8 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin mb-3" />
            <p className="text-xs font-medium">Loading school attendance records...</p>
          </div>
        ) : (
          <>
            {activeTab === 'daily' && (
              <DailyAttendanceView
                students={students}
                attendanceRecords={attendanceRecords}
                onSaveAttendance={handleSaveAttendance}
                currentTeacher={currentTeacher}
                onNavigateToStudents={() => setActiveTab('students')}
              />
            )}

            {activeTab === 'monthly' && (
              <MonthlyReportView
                students={students}
                attendanceRecords={attendanceRecords}
                currentTeacher={currentTeacher}
              />
            )}

            {activeTab === 'students' && (
              <StudentDirectoryView
                students={students}
                onOpenAddModal={handleOpenAddStudent}
                onOpenEditModal={handleOpenEditStudent}
                onDeleteStudent={handleDeleteStudent}
                currentTeacher={currentTeacher}
              />
            )}

            {activeTab === 'analytics' && (
              <AnalyticsView
                students={students}
                attendanceRecords={attendanceRecords}
                onNavigateToRollCall={() => setActiveTab('daily')}
              />
            )}
          </>
        )}
      </main>

      {/* Quiet Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-800">PM Shri Kendriya Vidyalaya Masimpur</span>
            <span aria-hidden="true">·</span>
            <span>School Attendance & Roll Call System</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <button
              onClick={() => setIsSupabaseSetupOpen(true)}
              className="hover:text-indigo-600 transition-colors"
            >
              Supabase SQL Guide
            </button>
            <span aria-hidden="true">·</span>
            <span>Teachers Only Access</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onTeacherAuthenticated={(teacher) => {
          setCurrentTeacherState(teacher);
          refreshData();
        }}
        isSupabaseMode={isSupabaseConnected}
      />

      <TeacherProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        teacher={currentTeacher}
        onLoggedOut={() => {
          setCurrentTeacherState(null);
          refreshData();
        }}
        onDataReset={refreshData}
        onTeacherUpdated={(updated) => {
          setCurrentTeacherState(updated);
          refreshData();
        }}
        isSupabaseMode={isSupabaseConnected}
      />

      <SupabaseSetupModal
        isOpen={isSupabaseSetupOpen}
        onClose={() => setIsSupabaseSetupOpen(false)}
        onConfigUpdated={() => {
          setSupabaseConfig(getSavedConfig());
          refreshData();
        }}
      />

      <StudentFormModal
        isOpen={isStudentFormOpen}
        onClose={() => {
          setIsStudentFormOpen(false);
          setEditingStudent(null);
        }}
        onSave={handleSaveStudent}
        initialStudent={editingStudent}
        defaultGrade={currentTeacher?.assigned_class || 'Class 10'}
        defaultSection={currentTeacher?.assigned_section || 'A'}
      />
    </div>
  );
}
